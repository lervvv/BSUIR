﻿using System.Net;
using System.Net.Sockets;
using System.Text;
class ChatServer
{
    static List<TcpClient> clients = new List<TcpClient>();

    static void Main()
    {
        Console.WriteLine("Выберите режим: Сервер - 1, Клиент - 2");
        string choice = Console.ReadLine();

        if (choice == "1")
        {
            StartServer();
        }
        else if (choice == "2")
        {
            StartClient();
        }
        else
        {
            Console.WriteLine("Неверный ввод.");
        }
    }

    static void StartServer()
    {
        Console.Write("Введите IP-адрес сервера: ");
        string ipAddress = Console.ReadLine();

        Console.Write("Введите порт: ");
        if (!int.TryParse(Console.ReadLine(), out int port))
        {
            Console.WriteLine("Некорректный порт.");
            return;
        }

        //проверка доступен ли порт
        if (!IsPortAvailable(port))
        {
            Console.WriteLine($"Порт {port} уже используется. Выберите другой.");
            return;
        }

        try
        {
            TcpListener server = new TcpListener(IPAddress.Parse(ipAddress), port);
            //запуск сервера
            server.Start();
            Console.WriteLine($"Сервер запущен на {ipAddress}:{port}");

            //запуск нового потока для ввода сообщений сервером
            Task.Run(() => ServerMessageLoop());

            //бесконечный цикл
            while (true)
            {
                TcpClient client = server.AcceptTcpClient();
                lock (clients) clients.Add(client);
                //запуск нового потока для обработки взаимодействия с клиентом
                Task.Run(() => HandleClient(client));
            }
        }
        catch
        {
            Console.WriteLine($"Ошибка при запуске сервера.");
        }
    }

    static void ServerMessageLoop()
    {
        //бесконечный цикл ввода сообщений сервером
        while (true)
        {
            string message = Console.ReadLine();
            if (message == "0") break;

            //отправка всем клиентам
            BroadcastMessage($"Сервер: {message}", null);
        }
    }

    static void BroadcastMessage(string message, TcpClient sender)
    {
        lock (clients)
        {
            foreach (var client in clients.Where(c => c != sender))
            {
                try
                {
                    byte[] buffer = Encoding.UTF8.GetBytes(message);
                    client.GetStream().Write(buffer, 0, buffer.Length);
                }
                catch { }
            }
        }
    }

    // Функция проверки доступности порта
    static bool IsPortAvailable(int port)
    {
        try
        {
            using (TcpListener listener = new TcpListener(IPAddress.Any, port))
            {
                listener.Start();
                listener.Stop();
                return true;
            }
        }
        catch
        {
            return false;
        }
    }

    static void HandleClient(TcpClient client)
    {
        NetworkStream stream = client.GetStream();
        byte[] buffer = new byte[1024];
        int bytesRead;

        while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
        {
            string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
            Console.WriteLine($"Сообщение от клиента: {message}");
            BroadcastMessage(message, client);
        }

        lock (clients) clients.Remove(client);
        client.Close();
    }

    static void StartClient()
    {
        Console.Write("Введите IP-адрес сервера: ");
        string ipAddress = Console.ReadLine();

        Console.Write("Введите порт: ");
        if (!int.TryParse(Console.ReadLine(), out int port))
        {
            Console.WriteLine("Некорректный порт.");
            return;
        }

        using TcpClient client = new TcpClient(ipAddress, port);
        NetworkStream stream = client.GetStream();
        Task.Run(() => ReceiveMessages(stream));

        Console.WriteLine("Введите сообщение (для выхода напишите `exit`):");
        while (true)
        {
            string message = Console.ReadLine();
            if (message.ToLower() == "exit") break;

            byte[] buffer = Encoding.UTF8.GetBytes(message);
            stream.Write(buffer, 0, buffer.Length);
        }
    }

    static void ReceiveMessages(NetworkStream stream)
    {
        byte[] buffer = new byte[1024];
        int bytesRead;

        while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
        {
            string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
            Console.WriteLine($"Получено: {message}");
        }
    }
}
