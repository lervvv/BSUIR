<?php

$mysqli = new mysqli('localhost', 'root', '123456', 'site');
