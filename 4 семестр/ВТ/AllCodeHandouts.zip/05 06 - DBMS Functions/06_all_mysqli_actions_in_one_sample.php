<?php

// 1. Connect to DBMS
$mysqli = new mysqli('localhost', 'root', '123456', 'site');

// 2. Setup encodings
$mysqli->set_charset('UTF8');

// 3. Run a query
$result = $mysqli->query("SELECT * FROM `site_users`");

// 4. Process results
if ($result !== false) {
    while ($row = $result->fetch_assoc()) {
        echo $row['su_fio'] . ' (' .
             $row['su_email'] . ')' . "\n";
    }
    $result->free();
}

// 5. Close connection
$mysqli->close();

/* SQL script to test this sample:

CREATE TABLE IF NOT EXISTS `site_users` (
  `su_uid` int(11) NOT NULL AUTO_INCREMENT,
  `su_login` varchar(200) NOT NULL DEFAULT '',
  `su_password` char(40) NOT NULL DEFAULT '',
  `su_fio` varchar(255) NOT NULL DEFAULT '',
  `su_email` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`su_uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

INSERT INTO `site_users` (`su_login`, `su_password`, `su_fio`, `su_email`) VALUES
('user1', 'e9d71f5ee7c92d6dc9e92ffdad17b8bd49418f98', 'John Smith', 'jh.sm@gmail.com'),
('user2', 'da4b9237bacccdf19c0760cab7aec4a8359010b0', 'Jane Smith', 'jn.sm@gmail.com'),
('user3', 'ff4b9cc7baccc1219c0760cab7aec4a8359010b0', 'Some User', 'su@gmail.com');
*/
