<?php

$result = $mysqli->query("SELECT * FROM `site_users`");

if ($result !== false) {
    while ($row = $result->fetch_assoc()) {
        echo $row['su_fio'] . ' (' . $row['su_email'] . ')';
    }
    $result->free();
}