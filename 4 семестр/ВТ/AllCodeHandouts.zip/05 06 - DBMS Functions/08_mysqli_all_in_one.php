<?php

// Disclaimer: HTML was mixed into PHP code here for simplification.
// This is a BAD decision! Do NOT follow this approach!!!

echo '<html>';
echo ' <head>';
echo '  <title>mysqli "PhpMyAdmin" ;)</title>';
echo ' </head>';
echo ' <body>';

function getForm($query = '')
{
    $all = '<table style="border-collapse:collapse;">';
    $all .= '<tr><td>';
    $all .= '<form action="' . $_SERVER['PHP_SELF'] . '" method="post">';
    $all .= '<textarea name="query" cols="70" rows="10">' . htmlspecialchars($query) . '</textarea>';
    $all .= '<br />';
    $all .= '<input type="submit" value="Go!" />';
    $all .= '</form>';
    $all .= '</td></tr>';
    $all .= '<tr><td>';
    return $all;
}

if (!isset($_POST['query'])) {
    echo getForm();
} else {
    $query = trim($_POST['query']);
    if (strlen($query) < 5) {
        echo getForm($query);
    } else {
        echo getForm($query);
        echo '<hr />';

        try {
            $mysqli = new mysqli('localhost', 'root', '123456', 'site');
        } catch (Exception $e) {
            exit($e->getMessage());
        }

        $mysqli->set_charset('UTF8');

        $errorMessage = '';
        try {
            $result = $mysqli->query($query);
        } catch (Exception $e) {
            $errorMessage = $e->getMessage();
        }

        $mysqliErrorNumber = $mysqli->errno;
        $mysqliErrorMessage = $mysqli->error;


        if (($errorMessage != '') || ($mysqliErrorNumber != 0)) {
            echo '<span style="color:red">Error (by Exception): ' . $errorMessage . '<br />Error code: ' . $mysqliErrorNumber . '<br />Error text: ' . $mysqliErrorMessage . '</span><hr />';
        } else {
            $allColumnsMetadata = $result->fetch_fields();
            echo 'Rows: ' . ($rows = $result->num_rows) . '. Cols: ' . ($cols = $result->field_count) . '.<br /><br />';
            echo '<table style="border: 1px solid black">';
            echo '<tr>';

            for ($i = 0; $i < $cols; $i++) {
                $column = $allColumnsMetadata[$i];
                echo '<td style="text-align: center; border: 1px solid black"><b>' . $column->name . '</b></td>';
            }
            echo '</tr>';

            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                foreach ($row as $cell) {
                    echo '<td style="border: 1px solid black">' . $cell . '</td>';
                }
                echo '<tr>';
            }

            echo '</table>';
            $mysqli->close();
        }

    }
}

echo '  </td></tr></table>';
echo ' </body>';
echo '</html>';