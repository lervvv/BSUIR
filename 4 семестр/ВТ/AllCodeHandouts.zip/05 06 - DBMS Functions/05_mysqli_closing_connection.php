<?php

$mysqli->close();
