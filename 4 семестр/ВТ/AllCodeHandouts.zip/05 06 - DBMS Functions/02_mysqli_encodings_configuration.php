<?php

// Usually this is enough:
$mysqli->set_charset('UTF8');

// But sometimes we may need this:
$mysqli->query("SET CHARACTER SET 'UTF8'");
$mysqli->query("SET CHARSET 'UTF8'");
$mysqli->query("SET NAMES 'UTF8'");