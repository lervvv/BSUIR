<?php

try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=site;charset=utf8', 'root', '123456', array(PDO::ATTR_PERSISTENT => false));
} catch (PDOException $e) {
    exit($e->getMessage());
}

$pdo->exec("SET CHARACTER SET 'UTF8'");
$pdo->exec("SET CHARSET 'UTF8'");
$pdo->exec("SET NAMES 'UTF8'");

// Binding columns for data selection
$result = $pdo->prepare("SELECT * FROM `site_users`");
$result->execute();
$result->bindColumn('su_fio', $fio);
$result->bindColumn('su_email', $email);

while ($row = $result->fetch(PDO::FETCH_BOUND)) {
    echo $fio . ' = ' . $email . "\n";
}

$result->closeCursor();

// Parameterization with prepared statements
$result = $pdo->prepare("SELECT * FROM `site_users` WHERE `su_uid`=:su_uid OR `su_email`=:su_email");
$result->bindValue(':su_uid', 1, PDO::PARAM_INT);
$result->bindValue(':su_email', 'jh.sm@gmail.com', PDO::PARAM_STR);
$result->execute();

// Print the whole result at once
print_r($result->fetchAll());

$result->closeCursor();
unset($pdo);