<?php

// Inserting data
$result = $mysqli->query("INSERT INTO `site_users`
                                (`su_fio`, `su_email`, `su_login`, `su_password`)
                                VALUES ('Smith J.', 'smith@gmail.com', 'smith', '" . sha1('smith') . "')");

// Selecting data
$result = $mysqli->query("SELECT * FROM `site_users`");