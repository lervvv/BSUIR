<?php

echo "<!DOCTYPE html>\n";
echo "<html>\n";
echo "<head>\n";
echo "    <title>News for " . date('Y.m.d') . "</title>\n";
echo "</head>\n";
echo "<body>\n\n";

echo "<h1>Today is " . date('Y.m.d') . "</h1>\n\n";

echo "</body>\n";
echo "</html>";