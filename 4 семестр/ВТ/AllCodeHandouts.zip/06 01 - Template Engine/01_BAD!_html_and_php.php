<!DOCTYPE html>
<html>
<head>
    <title>News for <?php echo date('Y.m.d')?></title>
</head>
<body>

<h1>Today is <?php echo date('Y.m.d')?></h1>

</body>
</html>