<?php

// Template reading
$templateData = file_get_contents('04_nano_templater.tpl');

// Placeholders replacement
$templateData = str_replace('{YEAR}', date('Y'), $templateData);
$templateData = str_replace('{MONTH}', date('m'), $templateData);
$templateData = str_replace('{DAY}', date('d'), $templateData);

// Results output
echo $templateData;