<?php

spl_autoload_register(function ($className) {
    $baseDir = __DIR__ . '/src/';
    $fileName = $baseDir . $className . '.class.php';
    $fileName = str_replace(['\\', '//'], ['/', '/'], $fileName);
    if (is_file($fileName)) {
        require $fileName;
    }
});

// Creating templater object.
$template = new Template;

// Reading main template.
$template->setMainTemplate('templates/main.tpl');

// Setting labels.
// In real applications this information usually comes from DB.
// And usually this information is language-dependant.
// Imagine, that for Russian it would be:
// $labelsArray = ['site_name' => 'Наш супер-сайт', 'today' => 'Сегодня'];
$labelsArray = ['site_name' => 'Our Super Site', 'today' => 'Today is'];
$template->setLabels($labelsArray);

// Setting "dynamic variables".
$template->setPlaceholder('year', date('Y'));
$template->setPlaceholder('month', date('m'));
$template->setPlaceholder('day', date('d'));

// Here this is just a random number :).
// In reality this should be some useful data (usually from DB).
$template->setPlaceholder('bottom_banner_text', mt_rand(100, 999));

// Processing the template.
$template->processTemplate();

// Outputting the final result.
echo $template->getFinalPage();