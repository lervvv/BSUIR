<!DOCTYPE html>
<html>
<head>
    <title>News for <?php echo date('Y.m.d') ?></title>
</head>
<body>

<?php if ((date('N') >= 6) && (date('N') <= 7)) { ?>
    <h1>Today is a weekend, no news!</h1>
<?php } else { ?>
    <h1>Today is <?php echo date('Y.m.d') ?></h1>
<?php } ?>

</body>
</html>