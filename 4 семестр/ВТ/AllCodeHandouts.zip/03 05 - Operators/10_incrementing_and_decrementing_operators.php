<?php

// Postincrement
$someVariable = 5;
echo "Should be 5: " . $someVariable++ . "\n";
echo "Should be 6: " . $someVariable . "\n";

// Preincrement
$someVariable = 5;
echo "Should be 6: " . ++$someVariable . "\n";
echo "Should be 6: " . $someVariable . "\n";

// Postdecrement
$someVariable = 5;
echo "Should be 5: " . $someVariable-- . "\n";
echo "Should be 4: " . $someVariable . "\n";

// Predecrement
$someVariable = 5;
echo "Should be 4: " . --$someVariable . "\n";
echo "Should be 4: " . $someVariable . "\n";

$i = 2;
$i += $i++ + ++$i;
echo $i;