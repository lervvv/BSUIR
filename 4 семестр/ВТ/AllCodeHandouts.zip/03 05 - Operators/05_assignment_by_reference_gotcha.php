<?php

$someArray = [5, 7, 11];

foreach ($someArray as &$value) {
    $value++;
}

print_r($someArray); // [6, 8, 12]

// If you forget this unset, the behavior may drive you crazy:
// unset($value);

foreach ($someArray as $key => $value) {
    echo $key . ' = ' . $value . "\n"; // 0 = 6, 1 = 8, 2 = 8
}

print_r($someArray); // [6, 8, 8]