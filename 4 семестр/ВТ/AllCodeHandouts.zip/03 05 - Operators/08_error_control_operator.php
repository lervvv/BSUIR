<?php

// Imagine that fle does not exist:
$someData = @file('non_existing_file');

// @ also works with expressions
$someValue = @$someArray[$someKey];

// Turns off all error messages
error_reporting(0);

// No more error message here
$someData = file('non_existing_file');

// No more error message here also
$someValue = @$someArray[$someKey];