<?php

$someVariable = 3;
$someVariable += 5; // $someVariable = $someVariable + 5

$someOtherVariable = "Hello ";
$someOtherVariable .= "There!"; // $someOtherVariable = $someOtherVariable . "There!"