<?php

$someArrayOne = array("a" => "apple", "b" => "banana");
$someArrayTwo = array("a" => "pear", "b" => "strawberry", "c" => "cherry");

// Union (one + two)
$someArrayThree = $someArrayOne + $someArrayTwo;
print_r($someArrayThree); // [a] => apple, [b] => banana, [c] => cherry

// Union (two + one)
$someArrayThree = $someArrayTwo + $someArrayOne;
print_r($someArrayThree); // [a] => pear, [b] => strawberry, [c] => cherry

// Union (one = one + two)
$someArrayOne += $someArrayTwo;
print_r($someArrayOne); // [a] => apple, [b] => banana, [c] => cherry

// Comparison
$someArrayOne = array("apple", "banana");
$someArrayTwo = array(1 => "banana", "0" => "apple");

var_dump($someArrayOne == $someArrayTwo); // bool(true)
var_dump($someArrayOne === $someArrayTwo); // bool(false)