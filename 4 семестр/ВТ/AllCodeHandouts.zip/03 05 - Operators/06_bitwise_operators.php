<?php

define('EXECUTE_PERMISSION', 0b0001);
define('WRITE_PERMISSION',   0b0010);
define('READ_PERMISSION',    0b0100);
define('OWNER_PERMISSION',   0b1000);

$userPermissions = 0b0000;

$userPermissions = $userPermissions | WRITE_PERMISSION; // Add write permission.
echo $userPermissions . "\n"; // 2 (0010)

if ($userPermissions & WRITE_PERMISSION) {
    echo "The user has write permission\n";
}

$userPermissions = $userPermissions ^ WRITE_PERMISSION; // Revoke write permission.
echo $userPermissions . "\n"; // 0 (0000)