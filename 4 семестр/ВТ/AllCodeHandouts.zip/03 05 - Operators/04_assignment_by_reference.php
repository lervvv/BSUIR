<?php

$basicVariable = 'Test';
$synonymVariable = &$basicVariable;

echo $synonymVariable; // 'Test'

$synonymVariable = 'OK'; // This also changes $basicVariable

echo $basicVariable; // 'OK'