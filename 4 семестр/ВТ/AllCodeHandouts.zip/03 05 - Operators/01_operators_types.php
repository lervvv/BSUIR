<?php

$someNewValue = !$someOldValue;

$someVariable = $operandA + $operandB;

$action = (empty($_POST['action'])) ? 'default' : $_POST['action'];
