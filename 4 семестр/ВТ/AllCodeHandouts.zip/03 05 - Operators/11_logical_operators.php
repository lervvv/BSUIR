<?php

if ((($dayOfWeek >= 6) && ($dayOfWeek <= 7)) || ($dayType == DAY_HOLYDAY)) {
    // ...
}
