<?php

$someVariable = 5;

$someVariable = $someVariable * 12;

// Do NOT do this! It complicates your code readability!
$someVariable = ($someOtherVariable = 4) + 5;
