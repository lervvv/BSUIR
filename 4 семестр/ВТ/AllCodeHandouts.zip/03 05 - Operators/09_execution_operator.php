<?php

$output = `ver`;
echo $output; // Microsoft Windows [Version 10.0.19044.1415]

/*
$xecutionString =
    "ffmpeg -i \"" . $originalVideoFileName . "\"" .
    " -i \"" . $firstAndLastPartsReplacementFileName . "\"" .
    " -i \"" . $shortLogoReplacementFileName . "\"" .
    " -i \"" . $longLogoReplacementFileName . "\"" .
    " -c:v libx264 -crf 0 -c:a copy -filter_complex" .
    " \"[0][1]overlay=W-w:H-h:enable='between(t,0," . $leadingLogoEndTime . ")'[v1];" .
    " [v1][2]overlay=y=H-h:enable='between(t," . $leadingLogoEndTime . "," . $longLogoStartTime . ")'[v2];" .
    " [v2][3]overlay=y=H-h+5:enable='between(t," . $longLogoStartTime . "," . $longLogoEndTime . ")'[v3];" .
    " [v3][2]overlay=y=H-h:enable='between(t," . $longLogoEndTime . "," . $trailingLogoStartTime . ")'[v4];" .
    " [v4][1]overlay=y=H-h:enable='between(t," . $trailingLogoStartTime . "," . $trailingLogoStartTime + 100 . ")'[v5]\"" .
    " -pix_fmt yuv420p -map \"[v5]\" -map 0:a \"" . $finalVideoFileName . "\"";
}

exec($executionString);
*/