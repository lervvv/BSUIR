<?php

// The simplest classic usage:

class SomeClass
{
}

class NotSomeClass
{
}
$someObject = new SomeClass;

var_dump($someObject instanceof SomeClass); // bool(true)
var_dump($someObject instanceof NotSomeClass); // bool(false)

// Hierarchy analysis:

class SomeParentClass
{
}

class SomeChildClass extends SomeParentClass
{
}

$someObject = new SomeChildClass();

var_dump($someObject instanceof SomeChildClass); // bool(true)
var_dump($someObject instanceof SomeParentClass); // bool(true)

// Interface implementation analysis:

interface SomeTrickyInterface
{
}

class SomeTrickyClass implements SomeTrickyInterface
{
}

$someObject = new SomeTrickyClass();

var_dump($someObject instanceof SomeTrickyClass); // bool(true)
var_dump($someObject instanceof SomeTrickyInterface); // bool(true)