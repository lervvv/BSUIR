<?php

$someVariable = "Hello ";
$someAnotherVariable = $someVariable . "World!"; // now $someAnotherVariable contains "Hello World!"

$someVariable = "Hello ";
$someVariable .= "World!";     // now $someVariable contains "Hello World!"

