<?php

$someVar = 10;
$someAnotherVar = 20;
$someArray[12] = 5;

// Simple: we are deleting a variable.
unset($someVar);

// We may easily delete even non-existing variable.
unset($someAnotherVar, $someNonExistingVar);

// This is how we delete an array element.
unset($someArray[12]);

// We may easily delete even non-existing array element.
unset($someArray[27]);

