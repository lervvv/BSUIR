<?php

$someVar = 10;
$someAnotherVar = 20;
$someArray[12] = 5;

if (isset($someVar)) {
    echo 'OK'; // OK
}

if (isset($someVar, $someAnotherVar)) {
    echo 'OK'; // OK
}

if (isset($someArray[12])) {
    echo 'OK'; // OK
}

if (isset($someNonExistingVar)) {
    echo 'OK'; // nothing
}

if (isset($someArray[27])) {
    echo 'OK'; // nothing
}