<?php

if ($argc > 0 ) {
    foreach ($argv as $argumentNumber => $argumentValue) {
        echo $argumentNumber . ' = ' . $argumentValue . "\n";
    }
}

// php 06_argc_and_argv.php One Two "Some more"

/*
0 = 06_argc_and_argv.php
1 = One
2 = Two
3 = Some more
*/