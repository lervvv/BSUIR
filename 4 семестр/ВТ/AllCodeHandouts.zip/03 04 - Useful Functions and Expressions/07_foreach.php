<?php

$someArray = ['name' => 'John', 'surname' => 'Smith', 'age' => 50];

foreach ($someArray as $key => $value) {
    if (is_string($value)) {
        echo '"' . $value . "\"\n";
    } elseif (is_int($value)) {
        echo '[' . $value . "]\n";
        $someArray[$key] = $value + 1;
    }
}

print_r($someArray);

/*
"John"
"Smith"
[50]

Array
(
    [name] => John
    [surname] => Smith
    [age] => 51
)
*/