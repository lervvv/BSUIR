<?php

$someArray = ['name' => 'John', 'surname' => 'Smith'];

var_dump($someArray);

/*
array(2) {
  'name' =>
  string(4) "John"
  'surname' =>
  string(5) "Smith"
}
*/

print_r($someArray);
/*
Array
(
    [name] => John
    [surname] => Smith
)
*/