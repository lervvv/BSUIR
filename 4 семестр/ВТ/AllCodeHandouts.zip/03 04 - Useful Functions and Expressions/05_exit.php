<?php

if ($argc < 3) {
    exit('USAGE: php scan.php SOURCE_DIR DESTINATION_DIR');
}
