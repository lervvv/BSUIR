<?php

$resultLabel = 'The result of SUM is ';
$operandOne = 2;
$operandTwo = 5;
echo $resultLabel . ($operandOne + $operandTwo);
// The result of SUM is 7