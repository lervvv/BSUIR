<?php

$someVariable = 5;
$someAnotherVariable = 10;
$someYetAnotherVariable = 'The SUM result is ';

echo $someVariable . "\n";
echo $someAnotherVariable . "\n";
echo $someYetAnotherVariable . ($someVariable + $someAnotherVariable) . "\n";

/*
5
10
The SUM result is 15
*/