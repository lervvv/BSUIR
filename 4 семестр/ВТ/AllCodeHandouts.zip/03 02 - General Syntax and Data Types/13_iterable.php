<?php

class ChattyArray implements Iterator // ... that extends Traversable
{
    private $someArray;

    public function __construct($givenArray)
    {
        $this->someArray = $givenArray;
    }

    #[ReturnTypeWillChange] function rewind()
    {
        return 'We are at the array beginning now, the value is ' . reset($this->someArray);
    }

    #[ReturnTypeWillChange] function current()
    {
        return 'We are at the same element now, the value is ' . current($this->someArray);
    }

    #[ReturnTypeWillChange] function key()
    {
        return 'We are at the same element now, the key is ' .  key($this->someArray);
    }

    #[ReturnTypeWillChange] function next()
    {
        return 'We are at the next element now, the value is ' . next($this->someArray);
    }

    #[ReturnTypeWillChange] function prev()
    {
        return 'We are at the previous element now, the value is ' .  prev($this->someArray);
    }

    function valid(): bool
    {
        return key($this->someArray) !== null;
    }
}

$chattyArray = new ChattyArray([2, 7, 8, 99]);
echo $chattyArray->next(); // We are at the next element now, the value is 7

exit();

// Yes, it's an iterable.
$someArray = [1, 5, 7];

// Yes, it's an iterable.
function justSomeFunction(): iterable
{
    return [1, 5, 7];
}

// Yes, it's an iterable.
$someFunction = function () {
    yield 1;
    yield 5;
    yield 7;
};


$something = array();

// The main idea is as follows:
if (is_iterable($something)) {
    foreach ($something as $key => $value) {
        echo 'Key = ' . $key . "\n";
        echo 'Value = ' . $value . "\n\n";
    }
}
