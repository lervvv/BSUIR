<?php

$singleByteEncoding = 'Test';
$multiByteEncoding = 'Тест';

echo $singleByteEncoding[2]; // s
echo $multiByteEncoding[2]; // �

$singleByteEncoding[2] = 'z';
$multiByteEncoding[2] = 'z';

echo $singleByteEncoding; // Tezt
echo $multiByteEncoding; // Тz�ст

// Just some cheat-sheet:
$aSingleQuotedString = 'Test';
$aDoubleQuotedString = "Test";
$aDoubleQuotedString = "Hotel \"Minsk\" and hotel 'Moscow'";
$aSingleQuotedString = 'Hotel "Minsk" and hotel \'Moscow\'';
$aDoubleQuotedString = "His age is $age";
$aDoubleQuotedString = "The value is {$values['val']}";
$aDoubleQuotedString = "Two\nlines";

$someVariable = 999;
$aDoubleQuotedString = "Some \"string\" with \n and $someVariable";
var_dump($aDoubleQuotedString);
// string(28) "Some "string" with
// and 999"

$someVariable = 999;
$aSingleQuotedString = 'Some \'string\' with \n and $someVariable';
var_dump($aSingleQuotedString);
// string(39) "Some 'string' with \n and $someVariable"

$aSingleQuotedString = 'Some string';
$aDoubleQuotedString = "Some string";