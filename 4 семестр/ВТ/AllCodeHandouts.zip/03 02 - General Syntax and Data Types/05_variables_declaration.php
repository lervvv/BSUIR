<?php

class SampleClass
{
    // Class properties, explicit declaration
    private static string $userName;
    private static ?string $userNickname; // May be null

    function doSomething() : void
    {
        $someVariable = 999; // "Ordinary variable", no explicit declaration
    }
}

$someVariable = 1;
$someVariable = true;
$otherVariable = "55 Test";
$result = $someVariable + $otherVariable; // It works :)
