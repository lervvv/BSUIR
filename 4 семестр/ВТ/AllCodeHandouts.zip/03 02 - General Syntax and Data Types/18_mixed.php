<?php

function printSomething(mixed $something): void
{
    echo 'This is something: ' . $something . "\n";
}

printSomething(1);
printSomething(10.15);
printSomething(true);
printSomething('Test');