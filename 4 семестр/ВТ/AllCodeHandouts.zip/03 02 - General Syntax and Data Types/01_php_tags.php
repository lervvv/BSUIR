<?php
// this is the opening tag

// PHP code here...

// this is the closing tag (NEVER USE IT!!!)
?>

<?= 'this is the equivalent of echo' ?>
<?php echo 'this approach is similar to the previous line' ?>