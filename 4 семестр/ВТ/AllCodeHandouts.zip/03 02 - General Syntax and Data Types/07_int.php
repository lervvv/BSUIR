<?php

$integerVar = 1234; // decimal number
$integerVar = 0123; // octal number (equivalent to 83 decimal)
$integerVar = 0o123; // octal number (as of PHP 8.1.0)
$integerVar = 0x1A; // hexadecimal number (equivalent to 26 decimal)
$integerVar = 0b11111111; // binary number (equivalent to 255 decimal)
$integerVar = 1_234_567; // decimal number (as of PHP 7.4.0)