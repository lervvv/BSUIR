<?php

// Yes, it's a callable:
function someFunction()
{

}

// Yes, it's a callable:
$someAnotherFunction = function () {
};

class SomeClass
{
    // Yes, it's a callable:
    public function someMethod(): void
    {

    }
}