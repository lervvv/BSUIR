<?php

$var1 = 1;
$vAr1 = 1;
