<?php

enum Season
{
    case Winter;
    case Spring;
    case Summer;
    case Autumn;
}

function doSomething(Season $season)
{
    // ...
}

doSomething(Season::Summer);
