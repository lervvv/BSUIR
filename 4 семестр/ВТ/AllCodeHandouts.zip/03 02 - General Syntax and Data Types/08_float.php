<?php

$floatVar = 1.234;
$floatVar = 1.2e3;
$floatVar = 7E-10;
$floatVar = 1_234.567; // as of PHP 7.4.0
