<?php

// $fileResource will be of a 'resource' type
$fileResource = fopen($_SERVER['PHP_SELF']);

while (!feof($fileResource)) {
    echo fgets($fileResource);
}
fclose($fileResource);