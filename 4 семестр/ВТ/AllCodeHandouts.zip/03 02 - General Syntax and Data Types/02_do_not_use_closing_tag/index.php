<?php
include 'library.php';
setcookie("Test", 999, time() + 3600);
echo "Hi!";
?>
