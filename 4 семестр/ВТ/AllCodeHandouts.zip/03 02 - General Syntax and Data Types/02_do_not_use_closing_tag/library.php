<?php
function someCoolFunction(): void
{
}
?>

