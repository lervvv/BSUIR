<?php

// 1. it has been assigned the constant null:
$someVariable = 1;
$someVariable = null;

if (is_null($someVariable)) {
    echo '$someVariable is null.';
}

// 2. it has not been set to any value yet:
if (is_null($someAnotherVariable)) {
    echo '$someAnotherVariable is null.';
}

// 3. it has been unset():
$someYetAnotherVariable = 1;
unset($someYetAnotherVariable);

if (is_null($someYetAnotherVariable)) {
    echo '$someYetAnotherVariable is null.';
}

