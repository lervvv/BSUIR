<?php
$x = 1 + "10.5";                // $x is float (11.5)
$x = 1 + "-1.3e3";              // $x is float (-1299)
$x = 1 + "bob-1.3e3";           // TypeError as of PHP 8.0.0, $x is integer (1) previously
$x = 1 + "bob3";                // TypeError as of PHP 8.0.0, $x is integer (1) previously
$x = 1 + "10 Small Pigs";       // $x is integer (11) and an E_WARNING is raised in PHP 8.0.0, E_NOTICE previously
$x = 4 + "10.2 Little Piggies"; // $x is float (14.2) and an E_WARNING is raised in PHP 8.0.0, E_NOTICE previously
$x = "10.0 pigs " + 1;          // $x is float (11) and an E_WARNING is raised in PHP 8.0.0, E_NOTICE previously
$x = "10.0 pigs " + 1.0;        // $x is float (11) and an E_WARNING is raised in PHP 8.0.0, E_NOTICE previously
