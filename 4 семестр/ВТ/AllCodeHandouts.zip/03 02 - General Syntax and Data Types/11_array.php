<?php

// Add an element:
$someArray['name'] = 'John';
$someArray['surname'] = 'Smith';

// Iterate through an array:
foreach ($someArray as $key => $value) {
    echo 'Key = ' . $key . "\n";
    echo 'Value = ' . $value . "\n\n";
}

// Access an element:
echo $someArray['name'];

// Check if an element exists (by index):
if (isset($someArray['name'])) {
    echo $someArray['name'];
}

// Remove an element:
unset($someArray['name']);

// Beware of indexes auto-assignment in multidimensional arrays!
$multidimensionalArray[10][15] = 'A';
$multidimensionalArray[10][] = 'B'; // $multidimensionalArray[10][0] = 'B'
$multidimensionalArray[][] = 'C'; // $multidimensionalArray[11][0] = 'C'


$someArrayOne = array(
    'one' => 'ONE',
    'two' => 'TWO',
    100   => 100,
    -100  => -100,
    'Test' // Key (index) is 101
);

$someArrayTwo = ['one' => 'ONE',
                 'two' => 'TWO',
                  100  => 100,
                 -100  => -100,
                 'Test'];  // Key (index) is 101


// These arrays are the same:
$someArrayOne = array('John', 'Smith');
$someArrayTwo[] = 'John';
$someArrayTwo[] = 'Smith';

// These arrays are the same:
$someArrayThree = array('name' => 'John', 'surname' => 'Smith');
$someArrayFour['name'] = 'John';
$someArrayFour['surname'] = 'Smith';

// These arrays are the same:
$someArrayFive = ['John', 'Smith'];
$someArraySix = ['name' => 'John', 'surname' => 'Smith'];


$someArray[5] = 'Test';     // (int) 5
$someArray['7'] = 'Test';   // (int) 7
$someArray['09'] = 'Test';  // (string) '09'
$someArray[true] = 'Test';  // (int) 1
$someArray[false] = 'Test'; // (int) 0
$someArray[12.7] = 'Test';  // (int) 12
$someArray[null] = 'Test';  // (string) ""

var_dump($someArray);

$someArray[500] = 'Good';
$someArray['name'] = 'John';
$someArray['surname'] = 'Smith';

$someArray = array();
// No need to pre-declare new dimension (e.g. unlike in Java collections),
// just use an index (ok key) and put an element into your array.
$someArray[500] = 'Good';
$someArray[999][12] = 'OK';
$someArray[5][21][77][0][16][56][21][1][1][1] = 'OK ;)';

// No need to declare any "length" or anything like that,
// just use an index (ok key) and put an element into your array.
$someArray[500] = 'Good';
$someArray[999] = 'OK';

$someArray = array(123, true, "Test");