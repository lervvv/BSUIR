<?php

/**
 * @param number $number
 * @return void
 */
function printNumber(int|float $number): void
{
    echo 'This is number: ' . $number . "\n";
}

printNumber(1);
printNumber(10.15);