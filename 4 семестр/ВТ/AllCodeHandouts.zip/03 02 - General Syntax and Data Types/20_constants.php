<?php

echo PHP_VERSION . "\n";        // 8.1.0
echo PHP_MAJOR_VERSION . "\n";  // 8
echo PHP_MINOR_VERSION  . "\n"; // 1
echo PHP_MAXPATHLEN . "\n";     // 2048
echo PHP_OS . "\n";             // WINNT
echo PHP_OS_FAMILY . "\n";      // Windows
echo PHP_SAPI . "\n";           // cli
echo PHP_EOL . "\n";            // \r\n
echo PHP_INT_MAX . "\n";        // 9223372036854775807
echo PHP_INT_MIN  . "\n";       // -9223372036854775808
// ... and so on.


// Define a constant:
define('SOME_CONSTANT', 'ABC');

// Check if a constant is defined:
if (defined('SOME_CONSTANT')) {
    // Use a constant:
    echo SOME_CONSTANT;
}

// 'Magic constant' sample:
echo 'This is line number' . __LINE__;

// Predefined sample:
echo 'We are using PHP version ' . PHP_VERSION;
