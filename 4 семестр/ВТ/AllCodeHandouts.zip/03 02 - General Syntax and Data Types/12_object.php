<?php

class SampleClass
{

}

$someObject = new SampleClass();

var_dump($someObject);