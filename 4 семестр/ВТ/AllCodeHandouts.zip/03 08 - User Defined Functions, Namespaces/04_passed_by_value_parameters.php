<?php

function fnc($x)
{
    $x = $x + 10;
    return $x;
}

$x = 10;
$y = fnc($x);
echo 'X = ' . $x . '; Y = ' . $y; // X = 10; Y = 20
