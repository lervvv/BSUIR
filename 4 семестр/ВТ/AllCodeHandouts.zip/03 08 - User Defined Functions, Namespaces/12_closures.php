<?php

$words = array('ABC', 'A', 'LongWord');

// The simplest closure
$reverseLengthComparator = function () {
    return function ($a, $b) {
        return -(strlen($a) <=> strlen($b));
    }; // Yes, here we need ;
}; // Yes, here we need ;

usort($words, $reverseLengthComparator());
print_r($words);

// And here we have a real function factory
$comparatorsFactory = function ($method) {
    return function ($a, $b) use ($method) {
        if ($method == 'alphabet') {
            return ($a <=> $b);
        }
        if ($method == 'codesums') {
            $cs_a = 0;
            $cs_b = 0;
            for ($i = 0; $i < strlen($a); $i++) {
                $cs_a += ord($a[$i]);
            }
            for ($i = 0; $i < strlen($b); $i++) {
                $cs_b += ord($b[$i]);
            }
            return ($cs_a <=> $cs_b);
        }
        return 0;
    };
};

// We may call our factory ad-hoc
usort($words, $comparatorsFactory('alphabet'));
print_r($words);

usort($words, $comparatorsFactory('codesums'));
print_r($words);

// Or we may produce comparators in advance and store
// them in some variables
$alphabetComparator = $comparatorsFactory('alphabet');
$codesumsComparator = $comparatorsFactory('codesums');

usort($words, $alphabetComparator);
print_r($words);

usort($words, $codesumsComparator);
print_r($words);