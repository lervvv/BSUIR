<?php

function sqr($x)
{
    return $x * $x;
}

$y = sqr(2);
echo $y; // 4
