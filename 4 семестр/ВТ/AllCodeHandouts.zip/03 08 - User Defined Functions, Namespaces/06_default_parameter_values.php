<?php

function fnc($x, $y = 99)
{
    echo 'X = ' . $x . ';  Y = ' . $y; // X = 10; Y = 99
}

fnc(10);