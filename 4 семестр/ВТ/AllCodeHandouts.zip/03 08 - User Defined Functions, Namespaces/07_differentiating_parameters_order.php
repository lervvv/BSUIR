<?php

function test(string $a, string $b, ?string $c = null, ?string $d = null)
{
    var_dump(func_get_args());
}

test(
b: 'value b',
a: 'value a',
d: 'value d',
);

/*
array(4) {
  [0] =>
  string(7) "value a"
  [1] =>
  string(7) "value b"
  [2] =>
  NULL
  [3] =>
  string(7) "value d"
}
*/