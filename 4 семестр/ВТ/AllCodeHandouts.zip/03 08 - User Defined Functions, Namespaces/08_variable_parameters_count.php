<?php

function fnc()
{
    echo func_num_args();         // 3
    echo func_get_arg(1);  // B
    print_r(func_get_args());     // Array([0] => A [1] => B [2] => C)
}

fnc('A', 'B', 'C');
