<?php

function fnc()
{
    static $staticCounter = 1;
    $normalCounter = 1;

    echo 'Static counter: ' . $staticCounter . ', Normal counter: ' . $normalCounter . "\n";
    
    $staticCounter++;
    $normalCounter++;
}

fnc(); // Static counter: 1, Normal counter: 1
fnc(); // Static counter: 2, Normal counter: 1
fnc(); // Static counter: 3, Normal counter: 1