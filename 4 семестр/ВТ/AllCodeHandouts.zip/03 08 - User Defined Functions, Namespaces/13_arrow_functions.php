<?php

// Imagine we have an array of objects (some messages).

class Message
{
    private ?int $id = null;

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function getId(): ?int
    {
        return $this->id;
    }
}

$messages = array();

for ($i = 0; $i < 10; $i++) {
    $messages[] = new Message($i);
}

// And now we want to have an array of messages ids only.

// 1) Classic approach:
$idsOldWay = array();
foreach ($messages as $message) {
    $idsOldWay[] = $message->getId();
}
print_r($idsOldWay);

// 2) Closure approach:
$idsClosure = array_map(function ($message) {
    return $message->getId();
}, $messages);
print_r($idsClosure);

// 3) Arrow function approach:
$idsArrowFunction = array_map(fn ($message) => $message->getId(), $messages);
print_r($idsArrowFunction);


