<?php

function fnc($x)
{
    $x = 99;
}

$x = 55;
fnc($x);
echo $x; // 55