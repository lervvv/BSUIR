<?php

// Let's assume we want to order these words by length
$words = array('ABC', 'A', 'LongWord');

// Classic approach forces us to define a function (comparator)
function compareByLength(string $a, string $b) : int
{
    return (strlen($a) <=> strlen($b));
}

usort($words, 'compareByLength');

// Or we may just use an anonymous function
usort($words, function ($a, $b) {
    return (strlen($a) <=> strlen($b));
});

print_r($words); //Array ([0] => A [1] => ABC [2] => LongWord)