<?php

namespace SomeProject\SomeLibrary\ComplexURL;

class URL
{
    public $JustForTest_ComplexURL = 1;
}
