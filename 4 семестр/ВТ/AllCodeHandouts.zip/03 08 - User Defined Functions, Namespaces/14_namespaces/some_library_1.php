<?php

namespace SomeProject\SomeLibrary\EasyURL;

class URL
{
    public $JustForTest_EesyURL = 1;
}