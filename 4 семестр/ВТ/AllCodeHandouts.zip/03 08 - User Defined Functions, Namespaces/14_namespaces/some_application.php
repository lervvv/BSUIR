<?php
require_once('some_library_1.php');
require_once('some_library_2.php');

use \SomeProject\SomeLibrary\EasyURL as Easy;
use \SomeProject\SomeLibrary\ComplexURL as Complex;

$easyURL = new Easy\URL();
$complexURL = new Complex\URL();
var_dump($easyURL);
var_dump($complexURL);

/*
class SomeProject\SomeLibrary\EasyURL\URL#1 (1) {
  public $JustForTest_EesyURL =>
  int(1)
}
class SomeProject\SomeLibrary\ComplexURL\URL#2 (1) {
  public $JustForTest_ComplexURL =>
  int(1)
}
*/
