<?php

function fnc($a, $b, ...$c)
{
    echo $a; // A
    echo $b; // B
    print_r($c); // Array ([0] => C [1] => D [2] => E)
}

fnc('A', 'B', 'C', 'D', 'E');