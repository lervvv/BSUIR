<?php

function sqr(float|int $x) : float|int
{
    return $x * $x;
}

$y = sqr(2);
echo $y; // 4
