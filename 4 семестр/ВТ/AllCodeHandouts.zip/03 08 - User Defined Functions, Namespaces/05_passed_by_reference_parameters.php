<?php

function fnc(&$y)
{
    $y = $y + 10;
}

$x = 10;
fnc($x);
echo 'X = ' . $x; // X = 20
