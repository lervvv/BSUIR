<?php

echo time() . "\n"; // 1645447946
echo microtime(true) . "\n"; // 1645447946.0964
echo microtime(false) . "\n"; // 0.09646400 1645447946
