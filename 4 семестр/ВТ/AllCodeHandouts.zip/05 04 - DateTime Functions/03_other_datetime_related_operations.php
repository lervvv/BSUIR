<?php

var_dump(checkdate(2, 29, 2010)); // bool(false)
var_dump(checkdate(2, 29, 2000)); // bool(true)

sleep(2); // Suspend script execution for 2 seconds
usleep(2000000);  // Suspend script execution for 2 seconds