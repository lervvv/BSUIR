<?php

// Registering autoloader
spl_autoload_register(function ($className) {
    $baseDir = __DIR__ . '/../src/classes/';
    $fileName = $baseDir . $className . '.php';
    $fileName = str_replace(['\\', '//'], ['/', '/'], $fileName);
    if (is_file($fileName)) {
        require $fileName;
    }
});

// Creating main objects
$config = new Config('../config/config.xml');
$logger = new Logger;
$urlProcessor = new URLProcessor;
$mySQL = new MySQL($logger, $config);

// Now we can analyze the URL and extract page data
$urlData = $urlProcessor->processURL($_GET['url'] ?? '');
$pageManager = new PageManager($logger, $mySQL, $urlProcessor, $config);
$pageData = $pageManager->getPageData();

// In case of '404' error...
if ($pageData['status'] == PageManager::NOT_FOUND) {
    header('HTTP/1.0 404 Not Found', true, 404);
    if (is_file($config->getGeneralConfig()['default404ResponseFile'])) {
        echo file_get_contents($config->getGeneralConfig()['default404ResponseFile']);
    }
    exit();
}

// In case of redirect
if ($pageData['status'] == PageManager::REDIRECT_NEEDED) {
    header('Location: ' . $pageData['redirect']);
    exit();
}

// This is the page user requested
$currentPage = $pageData['path'][count($pageData['path'])-1];

// Now we can process the template for current page
$template = new Template;
$template->setMainTemplate('../resources/templates/' . $currentPage['p_template']);

// For all pages we are executing the default handler
if (is_file('../src/handlers/' . $config->getGeneralConfig()['defaultHandler'])) {
    include_once '../src/handlers/' . $config->getGeneralConfig()['defaultHandler'];
}

// If a specific handler exists for this particular page, let's use it
if (is_file('../src/handlers/' . $currentPage['p_handler'])) {
    include_once '../src/handlers/' . $currentPage['p_handler'];
}

// All done, let's output the result!
$template->processTemplate();
echo $template->getFinalPage();