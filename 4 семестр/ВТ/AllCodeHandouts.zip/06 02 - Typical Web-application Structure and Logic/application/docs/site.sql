-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: site
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `labels`
--

DROP TABLE IF EXISTS `labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `labels` (
  `l_id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор надписи',
  `l_lng` varchar(2) NOT NULL COMMENT 'Язык надписи',
  `l_placeholder` varchar(255) NOT NULL COMMENT 'Плейсхолдер надписи',
  `l_value` text NOT NULL COMMENT 'Значение надписи',
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COMMENT='Надписи на страницах';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `labels`
--

LOCK TABLES `labels` WRITE;
/*!40000 ALTER TABLE `labels` DISABLE KEYS */;
INSERT INTO `labels` VALUES (1,'ru','today','Сегодня'),(2,'en','today','Today is'),(3,'ru','site_name','Просто сайт'),(4,'en','site_name','Just a site');
/*!40000 ALTER TABLE `labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `p_uid` int NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор',
  `p_parent` int NOT NULL DEFAULT '0' COMMENT 'Ссылка на родителя',
  `p_lang` char(2) NOT NULL DEFAULT '' COMMENT 'К какой языковой версии сайта относится страница',
  `p_title` text NOT NULL COMMENT 'TITLE',
  `p_keywords` text NOT NULL COMMENT 'meta keywords',
  `p_description` text NOT NULL,
  `p_url` varchar(255) NOT NULL DEFAULT '' COMMENT 'Часть URL''а',
  `p_ord` int NOT NULL DEFAULT '0' COMMENT 'Порядок в меню, карте сайта и т.п.',
  `p_name` varchar(255) NOT NULL DEFAULT '' COMMENT 'Имя на самой странице',
  `p_menu_name` varchar(255) NOT NULL DEFAULT '' COMMENT 'Имя в меню',
  `p_in_menu` char(1) NOT NULL DEFAULT 'Y' COMMENT 'Y - отображать в меню',
  `p_in_sitemap` char(1) NOT NULL DEFAULT 'Y' COMMENT 'Y - показывать на карте сайта',
  `p_text` text NOT NULL COMMENT 'Текст страницы',
  `p_file` varchar(255) NOT NULL DEFAULT 'default.php' COMMENT 'Обработчик',
  `p_template` varchar(255) NOT NULL DEFAULT 'default.tpl' COMMENT 'Шаблон',
  `p_template_print` varchar(255) NOT NULL DEFAULT 'default_print.tpl' COMMENT 'Шаблон версии для печати',
  `p_handler` varchar(255) NOT NULL COMMENT 'Обработчик страницы',
  PRIMARY KEY (`p_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,'ru','О фирме','О фирме','О фирме','about',1,'О фирме','О фирме','Y','Y','','default.php','default.tpl','default_print.tpl',''),(2,0,'ru','Клиентам','Клиентам','Клиентам','clients',2,'Клиентам','Клиентам','Y','Y','','default.php','default.tpl','default_print.tpl',''),(3,2,'ru','Физлицам','Физлицам','Физлицам','individuals',1,'Физлицам','Физлицам','Y','Y','','default.php','default.tpl','default_print.tpl',''),(4,2,'ru','Юрлицам','Юрлицам','Юрлицам','commercials',2,'Юрлицам','Юрлицам','Y','Y','','default.php','default.tpl','default_print.tpl',''),(5,0,'ru','Карта сайта','Карта сайта','Карта сайта','sitemap',3,'Карта сайта','Карта сайта','Y','N','','sitemap.php','sitemap.tpl','sitemap_print.tpl','sitemap.php'),(6,3,'ru','Богатым','','','rich',0,'Богатым','Богатым','Y','Y','','default.php','default.tpl','default_print.tpl',''),(7,3,'ru','Бедным','','','poor',0,'Бедным','Бедным','Y','Y','','default.php','default.tpl','default_print.tpl',''),(8,0,'ru','Главная страница','','','main',0,'Главная страница','Главная страница','N','N','','main.php','main.tpl','main_print.tpl',''),(9,0,'en','Main page','Main page','Main page','main',0,'Main page','Main page','N','N','','main.php','main.tpl','main_print.tpl',''),(10,0,'en','Sitemap','Sitemap','Sitemap','sitemap',0,'Sitemap','Sitemap','Y','N','','sitemap.php','sitemap.tpl','sitemap_print.tpl','sitemap.php'),(11,0,'en','About','About','About','about',0,'About','About','Y','Y','','default.php','default.tpl','default_print.tpl',''),(12,0,'en','For clients','For clients','For clients','clients',0,'For clients','For clients','Y','Y','','default.php','default.tpl','default_print.tpl',''),(13,0,'ru','404','404','404','404',0,'404','404','N','N','','default.php','default.tpl','default_print.tpl',''),(14,0,'en','404','404','404','404',0,'404','404','N','N','','default.php','default.tpl','default_print.tpl',''),(15,0,'ru','Новости','Новости','Новости','news',100,'Новости','Новости','Y','Y','','news.php','news.tpl','news_print.tpl','');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-17 10:59:13
