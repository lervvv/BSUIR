Simple web application
============

Purpose
------------
This application was created as a simple demo for educational purposes.

Database
------------
See the 'site.sql' file.

Disclaimer
------------
Yes, there are bugs.

Yes, the application is primitive.

NO, this is NOT a final beautiful production ready solution.