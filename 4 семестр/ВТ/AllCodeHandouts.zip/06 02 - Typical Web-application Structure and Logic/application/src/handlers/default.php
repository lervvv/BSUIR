<?php

// Each page shold have access to all labels.
$result = $mySQL->query("SELECT * FROM `labels` WHERE `l_lng` = '" . $urlData['language'] . "'");
$labels = array();
while ($row = $result['res']->fetch_assoc()) {
    $labels[$row['l_placeholder']] = $row['l_value'];
}
$template->setLabels($labels);

// This data comes from database and URL analysis.
$template->setPlaceholder('page_name', $currentPage['p_name']);
$template->setPlaceholder('page_title', $currentPage['p_title']);
$template->setPlaceholder('page_description', $currentPage['p_description']);
$template->setPlaceholder('page_keywords', $currentPage['p_keywords']);
$template->setPlaceholder('page_text', $currentPage['p_text']);
$template->setPlaceholder('language', $urlData['language']);

// Just for fun :)
$template->setPlaceholder('year', date('Y'));
$template->setPlaceholder('month', date('m'));
$template->setPlaceholder('day', date('d'));