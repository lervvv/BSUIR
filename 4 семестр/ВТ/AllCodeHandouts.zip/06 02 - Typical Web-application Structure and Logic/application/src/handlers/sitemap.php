<?php

/**
 * Generates the sitemap.
 * @param MySQL $mySQL Injected MySQL instance.
 * @param string $tplBefore Mini-template used before subpages block.
 * @param string $tplAfter Mini-template used after subpages block.
 * @param string $tplItem Mini-template for a single sitemap entry.
 * @param string $language Current language.
 * @param int $parent Parent page id.
 * @param string $preurl Path combined from all URL parts of all ancestor pages.
 * @return string Complete sitemap block.
 */
function getSitemap(MySQL $mySQL, string $tplBefore, string $tplAfter, string $tplItem, string $language, int $parent = 0, string $preurl = '')
{
    $all = '';
    $result = $mySQL->query("SELECT `p_uid`, `p_menu_name`, `p_url` from `pages` where `p_in_sitemap`='Y' AND `p_parent`='$parent' AND `p_lang`='$language' ORDER BY `p_ord` ASC");
    while ($row = $result['res']->fetch_assoc()) {
        $one = $tplItem;
        $one = str_replace('{ITEM_NAME}', $row['p_menu_name'], $one);
        $one = str_replace('{ITEM_URL}', $preurl . $row['p_url'], $one);

        $subpages = getSitemap($mySQL, $tplBefore, $tplAfter, $tplItem, $language, $row['p_uid'], $preurl . $row['p_url'] . '/');
        if ($subpages != '') {
            $one = str_replace('{SUBPAGES}', $tplBefore . $subpages . $tplAfter, $one);
        } else {
            $one = str_replace('{SUBPAGES}', '', $one);
        }

        $all .= $one;
    }

    return $all;
}

// We need specific mini-templates for the sitemap.
$tplBefore = file_get_contents('../resources/templates/sitemap/before.tpl');
$tplAfter = file_get_contents('../resources/templates/sitemap/after.tpl');
$tplItem = file_get_contents('../resources/templates/sitemap/item.tpl');

// And now we can generate the sitemap itself and set corresponding placeholder.
$template->setPlaceholder('sitemap', getSitemap($mySQL, $tplBefore, $tplAfter, $tplItem, $urlData['language']));