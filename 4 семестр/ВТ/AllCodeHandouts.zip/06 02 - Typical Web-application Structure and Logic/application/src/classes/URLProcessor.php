<?php

/**
 * Provides basic URL analysis functionality.
 */
class URLProcessor
{
    /**
     * @param string $url URL to analyze.
     * @return array Result of URL analysis.
     */
    public function processURL(string $url): array
    {
        // For security reasons let's remove everything except letters, numbers and forward slashes.
        $url = preg_replace("/[^\w\/]+/imsU", "", $url);

        $urlParts = explode('/', $url);
        $language = $urlParts[0] ?? '';
        $path = array();
        for ($i = 1; $i < count($urlParts) - 1; $i++) {
            $path[] = $urlParts[$i];
        }

        return ['language' => $language, 'path' => $path];
    }
}