<?php

/**
 * Provides access to XML config.
 */
class Config
{
    /**
     * @var array XML data in array form.
     */
    private array $XMLData;

    /**
     * @param string $XMLConfigPath Path to XML config file.
     */
    public function __construct(string $XMLConfigPath)
    {
        // This is how to read an XML file and immediately convert the data into array form.
        $this->xmlData = json_decode(json_encode(simplexml_load_file($XMLConfigPath)), true);
    }

    /**
     * @return string[] Returns MySQL config part.
     */
    public function getMySQLConfig(): array
    {
        return ['username' => $this->xmlData['mysql']['username'] ?? '',
            'password' => $this->xmlData['mysql']['password'] ?? '',
            'host' => $this->xmlData['mysql']['host'] ?? '',
            'database' => $this->xmlData['mysql']['database'] ?? ''];
    }

    /**
     * @return string[] Returns general config part.
     */
    public function getGeneralConfig(): array
    {
        return $this->xmlData['general'] ?? array();
    }
}