<?php

/**
 * Provides MySQL interface.
 */
class MySQL
{
    /**
     * @var mysqli Instance of MySQL connection.
     */
    private $lnk;

    /**
     * @var mysqli_result Instance of MySQL query execution result.
     */
    private $resResult;

    /**
     * @var int Number of rows in the MySQL query execution result.
     */
    private int $resRowsNumber;

    /**
     * @var int Number of fields (columns) in the MySQL query execution result.
     */
    private int $resFieldsNumber;

    /**
     * @var int Number of rows affected by the MySQL query execution result.
     */
    private int $resAffectedRowsNumber;

    /**
     * @var string MySQL error message.
     */
    private string $resErrorText;

    /**
     * @var int MySQL error code.
     */
    private int $resErrorCode;

    /**
     * @var float Query execution time.
     */
    private float $resTime;

    /**
     * @var array Query cache.
     */
    private array $queryCache;

    /**
     * @var Logger Injected logger instance.
     */
    private Logger $logger;

    /**
     * @var Config Injected config instance.
     */
    private Config $config;

    /**
     * @param Logger $logger Injected logger instance.
     * @param Config $config Injected config instance.
     */
    function __construct(Logger $logger, Config $config)
    {
        $this->logger = $logger;
        $this->config = $config;

        $mysqlConfig = $this->config->getMySQLConfig();
        $this->lnk = new mysqli($mysqlConfig['host'], $mysqlConfig['username'], $mysqlConfig['password'], $mysqlConfig['database']);

        if ($this->lnk->connect_error) {
            $this->logger->log_error($this->lnk->connect_error, $this->lnk->connect_errno);
        }

        if (!$this->lnk->set_charset("utf8")) {
            $this->logger->log_error($this->lnk->error, $this->lnk->errno);
        }

        $this->queryCache = array();
    }

    /**
     * Closes connection on object destruction.
     */
    function __destruct()
    {
        $this->lnk->close();
    }

    /**
     * @param $str string String to process.
     * @return string Processed string.
     */
    public function real_escape_string(string $str) : string
    {
        return $this->lnk->real_escape_string($str);
    }


    /**
     * @param $query string Query text.
     * @param $recache bool If set to 'true' causes update of cache for this particular query.
     * @return array
     */
    public function query(string $query, bool $recache = false) : array
    {
        // These keywords lead to data changes. The cache should be invalidated.
        if ((stripos($query, 'insert') !== false) ||
            (stripos($query, 'update') !== false) ||
            (stripos($query, 'delete') !== false) ||
            (stripos($query, 'replace') !== false) ||
            (stripos($query, 'truncate') !== false)) {
            $this->queryCache = array();
        }

        // If we can return the result from the cache, let's do it.
        if ((isset($this->queryCache[$query])) && ($recache === false)) {
            return $this->queryCache[$query];
        }

        // Now we can execute the query.
        $timeStart = microtime(TRUE);
        $result = $this->lnk->query($query);
        $timeFinish = microtime(TRUE);

        // Let's check for errors...
        if (0 !== ($errorCode = $this->lnk->errno)) {
            $this->log_error($this->lnk->error, $errorCode);
        }

        // Let's collect the results...
        $this->resRowsNumber = @$result->num_rows;
        $this->resFieldsNumber = @$result->field_count;
        $this->resAffectedRowsNumber = @$this->lnk->affected_rows;
        $this->resErrorText = @$this->lnk->error;
        $this->resErrorCode = @$this->lnk->errno;
        $this->resResult = $result;
        $this->resTime = $timeFinish - $timeStart;

        $resultingArray = array
        (
            'num_r' => $this->resRowsNumber,
            'num_f' => $this->resFieldsNumber,
            'aff_r' => $this->resAffectedRowsNumber,
            'err_t' => $this->resErrorText,
            'err_n' => $this->resErrorCode,
            'res' => $this->resResult,
            'time' => $this->resTime
        );

        // Now we can cache the result for future usage.
        $this->queryCache[$query] = $result;

        // All done, let's return the result.
        return $resultingArray;
    }
}