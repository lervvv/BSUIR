<?php

/**
 * Analyzes and returns requested page data.
 */
class PageManager
{
    /**
     * If set, redirect should be performed.
     */
    public const REDIRECT_NEEDED = 1;

    /**
     * Page found, normal template should be used.
     */
    public const OK_NORMAL = 2;

    // TODO: Implement reaction to 'print' keyword in the URL.
    /**
     * Page found, print template should be used.
     */
    public const OK_PRINT = 4;

    /**
     * Page not found.
     */
    public const NOT_FOUND = 8;

    /**
     * @var MySQL Injected MySQL instance.
     */
    private MySQL $mySQL;

    /**
     * @var Logger Injected logger instance.
     */
    private Logger $logger;

    /**
     * @var URLProcessor Injected URLProcessor instance.
     */
    private URLProcessor $urlProcessor;

    /**
     * @var Config Injected config instance.
     */
    private Config $config;

    /**
     * @var array URL data for local storage and usage.
     */
    private array $urlData;

    /**
     * @param Logger $logger Injected logger instance.
     * @param MySQL $mySQL Injected MySQL instance.
     * @param URLProcessor $urlProcessor Injected URLProcessor instance.
     * @param Config $config Injected config instance.
     */
    public function __construct(Logger $logger, MySQL $mySQL, URLProcessor $urlProcessor, Config $config)
    {
        $this->mySQL = $mySQL;
        $this->logger = $logger;
        $this->config = $config;
        $this->urlProcessor = $urlProcessor;
    }

    /**
     * @return array Returns data for current page and all parent pages.
     */
    public function getPageData(): array
    {
        // Let's analyze the URL.
        $this->urlData = $this->urlProcessor->processURL($_GET['url'] ?? '');

        // If language part is missing from URL, let's redirect to default language main page.
        if ((!isset($this->urlData['language'])) || ($this->urlData['language'] == '')) {
            return ['status' => PageManager::REDIRECT_NEEDED, 'redirect' => '/' . $this->config->getGeneralConfig()['defaultLanguage'] . '/'];
        }

        // If no page is specified in the URL, let's assume that we should process the default page (main page usually).
        if ((!isset($this->urlData['path'])) || (count($this->urlData['path']) == 0)) {
            $this->urlData['path'][] = $this->config->getGeneralConfig()['defaultPage'];
        }

        // Here we shall store all data about all pages specified in the URL.
        $path = array();

        // Just in case...
        if (!isset($this->urlData['path'])) {
            $this->urlData['path'] = array();
        }

        // Now let's collect all data about all pages specified in the URL.
        for ($i = 0; $i < count($this->urlData['path']); $i++) {
            $mysqlResult = $this->mySQL->query("SELECT * FROM `pages` WHERE `p_lang` = '" . $this->urlData['language'] . "' AND `p_url` = '" . $this->urlData['path'][$i] . "'");
            if ($mysqlResult['num_r'] != 1) {
                return ['status' => PageManager::NOT_FOUND];
            } else {
                $path[] = $mysqlResult['res']->fetch_assoc();
            }
        }

        // Done. Let's return the result.
        return ['status' => PageManager::OK_NORMAL, 'path' => $path];
    }

}