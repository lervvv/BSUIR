<?php

/**
 * Provides logging functionality.
 */
class Logger
{
    /**
     * @param string $errorText Text (error) message to log.
     * @param int $errorCode Error code to log.
     * @return void
     */
    public function log_error(string $errorText, int $errorCode = -1): void
    {
        if ($errorCode != -1) {
            echo '<span style="color:red">Error:</span> [' . $errorText . '], [' . $errorCode . ']<br />';
        } else {
            echo '<span style="color:red">Error:</span> [' . $errorText . ']<br />';
        }
    }
}