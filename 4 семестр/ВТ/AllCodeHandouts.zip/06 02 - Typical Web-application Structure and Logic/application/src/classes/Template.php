<?php

/**
 * Provides basic template engine functions. (Yes, this is the same code as in 'Template Engine' topic.)
 */
class Template
{
    /**
     * @var string Stores the whole template string representation.
     */
    private string $template;

    /**
     * @var array Stores placeholders data.
     */
    private $placeholders = array();

    /**
     * @var array Stores labels data. Labels are global placeholders for many pages.
     */
    private $labels = array();

    /**
     * Sets main template (NOT in constructor -- in order to choose template file after object creation).
     * @param string $mainTemplateFilename Main template file name.
     * @return void
     * @throws Exception
     */
    public function setMainTemplate(string $mainTemplateFilename): void
    {
        if (!is_file($mainTemplateFilename)) {
            throw new Exception('Main template [' . $mainTemplateFilename . '] not found.');
        }

        $this->template = file_get_contents($mainTemplateFilename);
    }

    /**
     * Directly replaces placeholders (skipping "store -> replace" process), for special cases.
     * @param string $name Placeholder name.
     * @param string $value Placeholder value.
     * @return void
     */
    public function setPlaceholderDirect(string $name, string $value): void
    {
        $this->template = str_replace($name, $value, $this->template);
    }

    /**
     * Stores placeholders for further processing.
     * @param string $name Placeholder name.
     * @param string $value Placeholder value.
     * @return void
     */
    public function setPlaceholder(string $name, string $value): void
    {
        $this->placeholders[$name] = $value;
    }

    /**
     * Stores labels for further processing. Labels supposed to be passed as array (from DB query).
     * @param array $labels_array Array [name => value] of labels.
     * @return void
     */
    public function setLabels(array $labels_array): void
    {
        $this->labels = $labels_array;
    }

    /**
     * Processes "dynamic variables", i.e. data generated on-the-fly.
     * @param array $dynamicVariableDataFromRegExp Data passed by preg_replace_callback().
     * @return string
     * @throws Exception
     */
    private function processDynamicVariables(array $dynamicVariableDataFromRegExp): string
    {
        $placeholderName = $dynamicVariableDataFromRegExp[1];
        if (isset($this->placeholders[$placeholderName])) {
            return $this->placeholders[$placeholderName];
        } else {
            throw new Exception('Placeholder [' . $placeholderName . '] not found.');
        }
    }

    /**
     * Processes "labels" (global placeholders for many pages).
     * @param array $labelDataFromRegExp Data passed by preg_replace_callback().
     * @return string
     * @throws Exception
     */
    private function processLabels(array $labelDataFromRegExp): string
    {
        $labelName = $labelDataFromRegExp[1];
        if (isset($this->labels[$labelName])) {
            return $this->labels[$labelName];
        } else {
            throw new Exception('Label [' . $labelName . '] not found.');
        }
    }

    /**
     * Processes subtemplates ("includes" subtemplates into main template).
     * @param array $subTemplateDataFromRegExp Data passed by preg_replace_callback().
     * @return string
     * @throws Exception
     */
    private function processSubTemplates(array $subTemplateDataFromRegExp): string
    {
        $subtemplateName = 'templates/' . $subTemplateDataFromRegExp[1];
        if (is_file($subtemplateName)) {
            return file_get_contents($subtemplateName);
        } else {
            throw new Exception('SubTemplate [' . $subtemplateName . '] not found.');
        }
    }

    /**
     * Performs placeholders replacement with data.
     * @return void
     */
    public function processTemplate(): void
    {
        while (preg_match("/{FILE=\"(.*)\"}|{DV=\"(.*)\"}|{LABEL=\"(.*)\"}/Ui", $this->template)) {
            $this->template = preg_replace_callback("/{DV=\"(.*)\"}/Ui", array($this, 'processDynamicVariables'), $this->template);
            $this->template = preg_replace_callback("/{LABEL=\"(.*)\"}/Ui", array($this, 'processLabels'), $this->template);
            $this->template = preg_replace_callback("/{FILE=\"(.*)\"}/Ui", array($this, 'processSubTemplates'), $this->template);
        }
    }

    /**
     * Returns final data (with optional pre-processing).
     * @param bool $removeComments Remove comments or not (default = remove).
     * @param bool $compress Remove results (remove extra spaces, etc.) or not (default = compress).
     * @return string
     */
    public function getFinalPage(bool $removeComments = true, bool $compress = true): string
    {
        $temp = $this->template;
        if ($removeComments == true) {
            $temp = preg_replace("/<!--.*-->/sU", "", $temp);
        }

        // TODO: Maybe change to regexs?
        if ($compress == true) {
            while (strpos($temp, '  ') !== false) {
                $temp = str_replace('  ', ' ', $temp);
            }

            while (strpos($temp, "\r\r") !== false) {
                $temp = str_replace("\r\r", "\r", $temp);
            }

            while (strpos($temp, "\n\n") !== false) {
                $temp = str_replace("\n\n", "\n", $temp);
            }

            while (strpos($temp, "\r\n\r\n") !== false) {
                $temp = str_replace("\r\n\r\n", "\r\n", $temp);
            }
        }

        return $temp;
    }

}