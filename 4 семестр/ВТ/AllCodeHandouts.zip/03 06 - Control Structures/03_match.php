<?php

$inputValue = '2';

$resultValue = match ($inputValue) {
    0 => "hello",
    '1', '2', '3' => "world",
};

echo $resultValue; // 'world'