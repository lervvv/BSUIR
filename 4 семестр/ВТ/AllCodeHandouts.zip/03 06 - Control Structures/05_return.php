<?php

function sqr(int|float $x): float
{
    return $x * $x;
}

echo sqr(2); // 4

class Math
{
    public static function sqr(int|float $x): float
    {
        return $x * $x;
    }
}

echo Math::sqr(2); // 4