<?php

declare(strict_types=1);
declare(encoding='ISO-8859-1');

// Code here


