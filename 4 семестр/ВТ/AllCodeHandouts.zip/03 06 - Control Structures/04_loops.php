<?php

$someVariable = 3;
while ($someVariable > 0) {
    echo $someVariable-- . "\n"; // 3 2 1
}

$someVariable = 10;
do {
    echo $someVariable-- . "\n"; // 10
} while ($someVariable > 50);

for ($someVariable = 0; $someVariable < 3; $someVariable++) {
    echo $someVariable . "\n"; // 0 1 2
}

$someArray = ['name' => 'John', 'surname' => 'Smith'];

foreach ($someArray as $key => $value) {
    echo $key . ' = ' . $value . "\n";
}
// name = John
// surname = Smith

foreach ($someArray as $value) {
    echo $value . "\n";
}
// John
// Smith

for ($i = 0; $i < 999; $i++) {
    if ($i < 500) {
        continue; // Skips the rest of the body, initiates new iteration.
    }
    echo $i . "\n";
    break; // Forces the loop to end.
}