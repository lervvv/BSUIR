<?php

$someVariable = 10.7;

// In PHP switch supports integers, doubles, strings, booleans, etc...
switch ($someVariable) {
    case 10:
        echo 'Ten';
        break; // This keyword is mandatory here.
    case 10.7:
        echo 'Ten point seven';
        break;
    case 'ABC':
        echo 'Some string';
        break; // This keyword is mandatory here.

    // This section is optional:
    default:
        echo 'Something unknown';
}
