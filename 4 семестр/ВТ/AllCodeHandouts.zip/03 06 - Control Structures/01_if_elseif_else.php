<?php

// The simples case:
if ($someVariable > 10) {
    // Do something
}

// Extended case:
if ($someVariable > 10) {
    // Do something
} else {
    // Do something else
}

// PHP-specific
if ($someVariable > 10) {
    // Do something
} elseif ($someVariable < 1) {
    // Do other something
} else {
    // Do something else
}

if (($someVariable > 15) && ($someOtherVariable < 5)) {
    if ($someCondition) {
        // Do something
    }
}