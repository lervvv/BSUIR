<?php

class SampleClass
{
    public string $publicProperty = '';
    protected bool $protectedProperty = true;
    private int $privateProperty = 0;

    public const PUBLIC_CONST = '';
    protected const PROTECTED_CONST = '';
    private const PRIVATE_CONST = '';

    public function __construct() {}

    public function publicMethod() {}
    protected function rotectedMethod() {}
    private function privateMethod() {}

    public function __destruct() {}
}

$someObject = new SomeClass();