<?php

class HttpConnection
{
    const PENDING_RESPONSE   = 0b0001;
    const RECEIVENING_HEADER = 0b0010;
    const RECEIVENING_DATA   = 0b0100;
    // ...
}

// Nice way to use class constants:
if ($httpConnection->getStatus() == HTTPConnection::RECEIVENING_DATA) {
    // ...
}

// Do NOT do this! This is WRONG!
// This is so-called 'magic number' -- extremely BAD practice!
if ($httpConnection->getStatus() == 4) {
    // ...
}
