<?php

class A
{
    public function example()
    {
        echo 'A';
    }
}

class B extends A
{
    public function example()
    {
        echo 'B';
        parent::example();
    }
}

$b = new B;
$b->example(); // BA
