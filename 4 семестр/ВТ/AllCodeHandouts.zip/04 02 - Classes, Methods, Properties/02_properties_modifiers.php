<?php

class StringsManipulator
{
    public string $currentStringRawRepresentation = '';
    protected string $currentString = '';
    protected string $uniqueId = '';
    private string $typeDependantHash = '';

    public const ENCODIND_DEPENDANT = 0b0001;
    public const ENCODIND_INDEPENDANT = 0b0010;

    public final const STRING_TEXT = 0b0001;
    public final const STRING_BINARY = 0b0010;

    public static int $justACounter = 0;

    public function __construct(string $initialString)
    {
        $this->currentString = $initialString;
        $this->uniqueId = uniqid();
        self::$justACounter++;
    }

}

$stringOne = new StringsManipulator('ABC');
$stringTwo = new StringsManipulator('DEF');

echo $stringOne::$justACounter . "\n"; // 2
echo $stringTwo::$justACounter . "\n"; // 2