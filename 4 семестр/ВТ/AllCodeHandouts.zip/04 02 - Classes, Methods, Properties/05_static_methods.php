<?php

class Config
{
    private static $instance;

    protected function __construct() {}
    protected function __clone() {}

    public function __wakeup()
    {
        throw new Exception("Cannot unserialize a singleton.");
    }

    public static function getInstance(): Config
    {
        if (is_null(self::$instance)) {
            self::$instance = new Config;
        }
        return self::$instance;
    }

}

$config = Config::getInstance();

class Math
{
    public static function inc($x, $increment = 1)
    {

        return $x + $increment;

    }
}

echo Math::inc(5); // 6
