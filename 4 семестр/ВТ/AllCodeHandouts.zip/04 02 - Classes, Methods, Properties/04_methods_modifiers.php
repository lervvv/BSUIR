<?php

class StringsManipulator
{
    public string $currentStringRawRepresentation = '';
    protected string $currentString = '';
    protected string $uniqueId = '';
    private string $typeDependantHash = '';

    public function __construct(string $initialString)
    {
        $this->currentString = $initialString;
        $this->uniqueId = uniqid();
    }

    protected function calculateHash(string $inputString) : string
    {
        return '';
    }

    private function typeDependantHash(string $inputString) : string
    {
        return '';
    }

    final public function getCryptoHash(string $inputString) : string
    {
        return '';
    }

    abstract public function getNationalHash(string $inputString) : string;

}