<?php

class SomeClass {
    public string $someValue;
}

$objectOne = new SomeClass();
$objectTwo = new SomeClass();

$objectOne->someValue = 'A';
$objectTwo->someValue = 'A';
$objectThree = $objectTwo;
var_dump($objectOne == $objectTwo);    // true
var_dump($objectOne === $objectTwo);   // false
var_dump($objectTwo === $objectThree); // true

$objectOne->someValue = 'X';
$objectTwo->someValue = 'Y';
var_dump($objectOne == $objectTwo);   // false