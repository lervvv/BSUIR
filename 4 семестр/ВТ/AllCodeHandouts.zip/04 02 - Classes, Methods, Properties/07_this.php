<?php

class SomeClass
{
    private $property;

    public function __construct($property)
    {
        $this->property = $property;
        $this->initSomething();
    }

    private function initSomething()
    {

    }
}

$someObject = new SomeClass(999);
