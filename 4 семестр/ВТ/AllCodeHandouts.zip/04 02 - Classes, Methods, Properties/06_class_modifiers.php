<?php

abstract class DbmsConnection
{
    abstract public function connect() : bool;
}

class MySqlConnection extends DbmsConnection {
    public function connect() : bool {
        return true;
    }
}

class OracleConnection extends DbmsConnection {
    public function connect() : bool {
        return true;
    }
}

final class ExtremelyStrongEncryption
{
    public function encryptForever() : string
    {
        return '';
    }
}