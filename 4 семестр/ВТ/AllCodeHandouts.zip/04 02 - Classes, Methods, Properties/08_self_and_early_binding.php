<?php

class A
{
    public static function whoAmI()
    {
        echo __CLASS__;
    }

    public static function justSomeTest()
    {
        self::whoAmI();
    }
}

class B extends A
{
    public static function whoAmI()
    {
        echo __CLASS__;
    }
}

B::justSomeTest(); // A
