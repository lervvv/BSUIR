<?php

// Search by key
$someArray = array('name' => 'Ivan', 'age' => 40);
if (isset($someArray['age'])) {
    echo $someArray['age'];
}

// Search by value (mind the 3rd parameter!!!)
$someArray = array('A', 99, true);
$x = in_array(99, $someArray); // true
$x = in_array(99999, $someArray); // true (!?!?!?!?)
$x = in_array(99999, $someArray, true); // false

// Search for a key by value (mind the 3rd parameter!!!)
$x = array_search(99, $someArray); // 1
$x = array_search(99999, $someArray, true); // false