<?php

// Try running this script with web server
// and from the command line!

$someVariable = 'Test';
print_r($GLOBALS);