<?php

// Must be en each separately
// started script!
session_start();

print_r($_SESSION);

/*
Array
(
    [someVariable] => 999
)
*/