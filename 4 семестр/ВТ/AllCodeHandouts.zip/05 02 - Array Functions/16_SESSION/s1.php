<?php

// Must be en each separately
// started script!
session_start();

$_SESSION['someVariable'] = 999;