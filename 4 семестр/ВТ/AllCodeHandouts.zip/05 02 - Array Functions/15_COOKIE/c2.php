<?php

print_r($_COOKIE);

/*
Array
(
    [TestVariable] => TestValue
)
*/