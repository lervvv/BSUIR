<?php

setcookie("TestVariable", "TestValue", time()+3600);