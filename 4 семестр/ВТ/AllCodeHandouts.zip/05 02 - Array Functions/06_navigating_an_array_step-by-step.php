<?php

$someArray = [15, 19, 31, 85, 123];
echo reset($someArray) . "\n"; // 15
echo next($someArray) . "\n";  // 19
echo prev($someArray) . "\n";  // 15
echo current($someArray) . "\n";     // 15
echo key($someArray) . "\n";         // 0
echo end($someArray) . "\n";  // 123