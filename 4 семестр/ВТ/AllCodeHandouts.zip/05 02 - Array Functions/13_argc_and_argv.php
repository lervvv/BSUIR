<?php

// Run this script from command line:
// php 13_argc_and_argv.php A B C D E

echo $argc . "\n"; // 6
print_r($argv);

/*
Array
(
    [0] => 13_argc_and_argv.php
    [1] => A
    [2] => B
    [3] => C
    [4] => D
    [5] => E
)
*/