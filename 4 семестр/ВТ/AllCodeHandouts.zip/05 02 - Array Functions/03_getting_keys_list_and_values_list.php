<?php

$someArray = array('name' => 'Ivan', 'age' => 40, 'has_car' => true);
$keysArray = array_keys($someArray); // array(name, age, has_car)

$someArray = array(100 => 'A', 123 => 99, 555 => true);
$newArray = array_values($someArray); // array(0 => ‘A’, 1 => 99, 2 => true)
