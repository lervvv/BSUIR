<form method="post" action="10_FILES.php" enctype="multipart/form-data">
    File 1: <input type="file" name="f1" /><br />
    File 2: <input type="file" name="f2" /><br />
    <input type="submit" value="Go!" />
</form>

<?php

// Just submit the form data.

print_r($_FILES);