<?php

// This function accepts an array by value:
function incrementNumericElementsBV(array $inputArray, int|float $incrementValue = 1) : array
{
    foreach ($inputArray as $key => $value) {
        if (is_array($value)) {
            $inputArray[$key] = incrementNumericElemetsBV($value, $incrementValue);
        } elseif ((is_double($value)) || (is_integer($value))) {
            $inputArray[$key] = $value + $incrementValue;
        }
    }
    return $inputArray;
}

$someArray = [10, 'Test', '11', 98.5];
$newArray = incrementNumericElementsBV($someArray, 5);
print_r($newArray);

/*
Array
(
    [0] => 15
    [1] => Test
    [2] => '11'
    [3] => 103.5
)
*/

// This function accepts an array by reference:
function incrementNumericElementsBR(array &$inputArray, int $incrementValue = 1)
{
    foreach ($inputArray as $key => $value) {
        if (is_array($value)) {
            incrementNumericElementsBR($value, $incrementValue);
            $inputArray[$key] = $value;
        } elseif ((is_double($value)) || (is_integer($value))) {
            $value += $incrementValue;
            $inputArray[$key] = $value;
        }
    }
}

$someArray = [10, 'Test', '11', 98.5];
incrementNumericElementsBR($someArray, 7);
print_r($someArray);

/*
Array
(
    [0] => 17
    [1] => Test
    [2] => '11'
    [3] => 105.5
)
*/