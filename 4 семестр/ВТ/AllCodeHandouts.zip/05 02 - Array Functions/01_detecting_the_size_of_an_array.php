<?php

$someArray = array(array('A', 'B'), array('C', 'D'));
echo count($someArray) . "\n"; // 2
echo count($someArray, COUNT_RECURSIVE) . "\n"; // 6