<?php

$someArray = array(1, 5, 8, 15, 21, 34);
$randomElements = array_rand($someArray, 3);
print_r($randomElements);

/*
Pay attention: here we have KEYS, not values!
Array
(
    [0] => 0
    [1] => 1
    [2] => 4
)
*/