<?php

print_r($_ENV); // Usually just: Array()

echo getenv('PATH');
// C:\Program Files\Common Files\Oracle\Java\javapath;C:\WINDOWS\system32; ...