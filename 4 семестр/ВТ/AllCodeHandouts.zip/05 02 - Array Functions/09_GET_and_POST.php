<form method="post" action="09_GET_and_POST.php">
    A: <input type="text" name="a" /><br />
    B: <input type="text" name="b" /><br />
    C: <input type="text" name="c" /><br />
    <input type="submit" value="Go!" />
</form>

<?php

// Request this page like
// http://127.0.0.1/09_GET_and_POST.php?a=99&b=ABD&c=1
// or just submit the form data.

print_r($_GET);
print_r($_POST);