<?php

$someArray = array('A' => 95, 'Z' => 17, 'N' => 35);
sort($someArray);  // array (0 => 17, 1 => 35, 2 => 95)
rsort($someArray); // array (0 => 95, 1 => 35, 2 => 17)

$someArray = array('A' => 95, 'Z' => 17, 'N' => 35);
asort($someArray);  // array ('Z' => 17, 'N' => 35, 'A' => 95)
arsort($someArray); // array ('A' => 95, 'N' => 35, 'Z' => 17)

$someArray = array('A' => 95, 'Z' => 17, 'N' => 35);
ksort($someArray);  // array ('A' => 95, 'N' => 35, 'Z' => 17)
krsort($someArray); // array ('Z' => 17, 'N' => 35, 'A' => 95)

$orders = array
(
    array(10, 34, 34, 67),
    array(1, 2, 6),
    array(2000, 90),
    array(15, 67),
    array(34, 87, 34)
);

function ordersComparator($a, $b) : int
{
    $sum_a = 0;
    $sum_b = 0;

    foreach ($a as $v) {
        $sum_a += $v;
    }

    foreach ($b as $v) {
        $sum_b += $v;
    }

    return $sum_a <=> $sum_b;
}

print_r($orders);
usort($orders, 'ordersComparator');
print_r($orders);

/*
Array
(
    [0] => Array
        (
            [0] => 1
            [1] => 2
            [2] => 6
        )

    [1] => Array
        (
            [0] => 15
            [1] => 67
        )

    [2] => Array
        (
            [0] => 10
            [1] => 34
            [2] => 34
            [3] => 67
        )

    [3] => Array
        (
            [0] => 34
            [1] => 87
            [2] => 34
        )

    [4] => Array
        (
            [0] => 2000
            [1] => 90
        )
)
*/