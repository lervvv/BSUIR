<?php

// Try running this script with web server
// and from the command line!

print_r($_SERVER);