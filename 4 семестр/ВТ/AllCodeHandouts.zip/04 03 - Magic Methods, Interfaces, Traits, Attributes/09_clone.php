<?php

class TempFileManager
{
    private string $fileName;

    public function __construct($userDefinedFileName = '')
    {
        if ($userDefinedFileName != '') {
            $this->fileName = $userDefinedFileName;
        } else {
            $this->fileName = md5(rand());
        }
    }

    public function __clone()
    {
        $this->fileName = md5(rand());
    }
}

$tempFileOne = new TempFileManager();
$tempFileTwo = clone $tempFileOne;

var_dump($tempFileOne);
/*
class TempFileManager#1 (1) {
  private string $fileName =>
  string(32) "c45ad39511884303df2924b5f01fdcb3"
}
*/

var_dump($tempFileTwo);
/*
class TempFileManager#2 (1) {
  private string $fileName =>
  string(32) "cdd1683525d18df311d9163c7c227f63"
}
*/