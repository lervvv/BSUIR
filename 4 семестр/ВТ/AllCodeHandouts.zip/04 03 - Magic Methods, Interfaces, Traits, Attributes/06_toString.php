<?php

class TempFileManager
{
    private string $fileName;

    public function __construct($userDefinedFileName = '')
    {
        if ($userDefinedFileName != '') {
            $this->fileName = $userDefinedFileName;
        } else {
            $this->fileName = md5(rand());
        }
    }

    public function __toString() : string
    {
        return "The file name is [" . $this->fileName . "]\n";
    }
}

$tempFile = new TempFileManager();
echo $tempFile;
// The file name is [6c4d2b2c2689259911855f2c4a18cd64]