<?php

class TempFileManager
{
    private string $fileName;

    public function __construct($userDefinedFileName = '')
    {
        if ($userDefinedFileName != '') {
            $this->fileName = $userDefinedFileName;
        } else {
            $this->fileName = md5(rand());
        }
    }

    public function __destruct()
    {
        if (is_file($this->fileName)) {
            unlink($this->fileName);
        }
    }
}

// Before PHP 8
class Money
{
    public Currency $currency;
    public int $amount;

    public function __construct(
        Currency $currency,
        int $amount,
    )
    {
        $this->currency = $currency;
        $this->amount = $amount;
    }
}

// Since PHP 8
class NewMoney
{
    public function __construct(
        public Currency $currency,
        public int $amount,
    )
    {
    }
}