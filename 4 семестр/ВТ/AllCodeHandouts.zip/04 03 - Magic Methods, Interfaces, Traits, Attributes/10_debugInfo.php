<?php

class Liar
{
    private $someValue;

    public function __construct($someValue)
    {
        $this->someValue = $someValue;
    }

    public function __debugInfo()
    {
        return [
            'username' => 'user1',
            'password' => 'password1',
        ];
    }
}

$liar = new Liar(10);
var_dump($liar);
/*
class Liar#1 (2) {
  public $username =>
  string(5) "user1"
  public $password =>
  string(9) "password1"
}
*/