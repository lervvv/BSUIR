<?php
class CallableClass
{
    public function __invoke($x)
    {
        var_dump($x);
    }
}
$someObject = new CallableClass;
$someObject(5);
// int(5)

var_dump(is_callable($someObject));
// bool(true)