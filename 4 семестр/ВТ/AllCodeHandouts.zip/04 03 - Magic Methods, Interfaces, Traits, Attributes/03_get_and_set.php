<?php

class SomeClass
{
    public function __get($name)
    {
        echo 'Property [' . $name . "] does not exist or is inaccessible!\n";
    }

    public function __set($name, $value)
    {
        echo 'Property [' . $name . "] does not exist or is inaccessible! The value [" .
             $value . "] was not assigned!\n";
    }
}

$someObject = new SomeClass;
$someObject->someProperty;
// Property [someProperty] does not exist or is inaccessible!

$someObject->someProperty = 'someValue';
// Property [someProperty] does not exist or is inaccessible! The value [someValue] was not assigned!