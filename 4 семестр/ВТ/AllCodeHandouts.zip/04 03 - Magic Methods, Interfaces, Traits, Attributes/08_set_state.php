<?php

class SomeClass
{
    public string $somePropertyOne;
    public string $somePropertyTwo;

    public static function __set_state($someArray)
    {
        $someObject = new SomeClass;
        $someObject->somePropertyOne = $someArray['somePropertyOne'];
        $someObject->somePropertyTwo = $someArray['somePropertyTwo'];
        return $someObject;
    }
}

$testObject = new SomeClass;
$testObject->somePropertyOne = 'One';
$testObject->somePropertyTwo = 'Two';

$executableCode = var_export($testObject, true);
echo $executableCode;
/*
  SomeClass::__set_state(array(
  'somePropertyOne' => 'One',
  'somePropertyTwo' => 'Two',))
*/

eval('$newTestObject = ' . $executableCode . ';');
var_dump($newTestObject);

/*
class SomeClass#2 (2) {
  public string $somePropertyOne =>
  string(3) "One"
  public string $somePropertyTwo =>
  string(3) "Two"
}
*/