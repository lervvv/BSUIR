<?php

// Interface definition
interface iStorableInDB
{
    public function store();
    public function retrieve();
}

// Interface implementation:
// this class MUST implement
// store() and retrieve() methods.
class LongConnection implements iStorableInDB
{
    // store() and retrieve() methods implementation here
}