<?php

class SomeClass
{
    public function __isset($name)
    {
        echo 'Property [' . $name . "] does not exist or is inaccessible!\n";
    }

    public function __unset($name)
    {
        echo 'Property [' . $name . "] does not exist or is inaccessible!\n";
    }
}

$someObject = new SomeClass;
if (isset($someObject->someProperty)) {
    // Do something.
}
// Property [someProperty] does not exist or is inaccessible!

unset ($someObject->someProperty);
// Property [someProperty] does not exist or is inaccessible!