<?php

class SomeClass
{
    public function __call($name, $arguments)
    {
        echo 'Method [' . $name . '] was called with arguments [' .
             implode(', ', $arguments) . "], but it does not exist!\n";
    }

    public static function __callStatic($name, $arguments)
    {
        echo 'Static method [' . $name . '] was called with arguments [' .
            implode(', ', $arguments) . "], but it does not exist!\n";
    }
}

$someObject = new SomeClass;
$someObject->runTest('A', 'B', 'C');
// Method [runTest] was called with arguments [A, B, C], but it does not exist!

SomeClass::runTest(1, 2, 3);
// Static method [runTest] was called with arguments [1, 2, 3], but it does not exist!