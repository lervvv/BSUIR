<?php

// Declaring and using an attribute
#[Attribute]
class LosslessSrializable{}

#[LosslessSrializable]
class SafeToSerialize{}

class UnsafeToSerialize{}

$objects[] = new SafeToSerialize;
$objects[] = new UnsafeToSerialize;

foreach ($objects as $object) {
    $reflection = new ReflectionClass($object);
    $attributes = $reflection->getAttributes();
    foreach ($attributes as $attribute) {
        if ($attribute->getName() == 'LosslessSrializable') {
            echo 'This is an object of [' . $reflection->getName() . '] class. It is safe to serialize.';
        }
    }
}

// This is an object of [SafeToSerialize] class. It is safe to serialize.