<?php

trait tNicePropertiesOutput
{
    public function getNicePropertiesOutput() : string
    {
        $objectVariables = get_object_vars($this);
        $result = '';
        foreach ($objectVariables as $variableName => $variableValue) {
            $result .= '[' . $variableName . '] = [' . $variableValue . "]\n";
        }
        return $result;
    }

}

class SomeClassOne
{
    use tNicePropertiesOutput;

    public int $somePropertyOne = 1;
    public int $somePropertyTwo = 2;
    public int $somePropertyThree = 3;

    public function __toString(): string
    {
        return $this->getNicePropertiesOutput();
    }
}

class SomeClassTwo
{
    use tNicePropertiesOutput;

    public string $somePropertyOne = 'One';
    public string $somePropertyTwo = 'Two';

    public function __toString(): string
    {
        return $this->getNicePropertiesOutput();
    }
}

$someObjectOne = new SomeClassOne();
echo $someObjectOne;
/*
[somePropertyOne] = [1]
[somePropertyTwo] = [2]
[somePropertyThree] = [3]
*/

$someObjectTwo = new SomeClassTwo();
echo $someObjectTwo;
/*
[somePropertyOne] = [One]
[somePropertyTwo] = [Two]
*/