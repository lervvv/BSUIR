<?php

class Connection
{
    protected $link;
    private $connectionString, $username, $password;
    private $lastActionTimeStamp;

    public function __construct($connectionString, $username, $password)
    {
        echo "Constructor called\n";
        $this->connectionString = $connectionString;
        $this->username = $username;
        $this->password = $password;
        $this->connect();
    }

    public function __destruct() {
        echo "Destructor called\n";
        $this->close();
    }

    private function connect()
    {
        echo "connect() called\n";
        // $this->link = new PDO($this->connectionString, $this->username, $this->password);
        $this->lastActionTimeStamp = microtime(true);
    }

    private function close()
    {
        echo "close() called\n";
        $this->lastActionTimeStamp = microtime(true);
    }

    public function __sleep()
    {
        echo "__sleep() called\n";
        return array('connectionString', 'username', 'password');
    }

    public function __wakeup()
    {
        echo "__wakeup() called\n";
        $this->connect();
    }

    public function __serialize(): array
    {
        echo "__serialize() called\n";
        return [
            'connectionString' => $this->connectionString,
            'credentials' => ['username' => $this->username,
                              'password' => $this->password],
        ];
    }

    public function __unserialize(array $data): void
    {
        echo "__unserialize() called\n";
        $this->connectionString = $data['connectionString'];
        $this->username = $data['credentials']['username'];
        $this->password = $data['credentials']['password'];
    }

}

$connection = new Connection("mysql:127.0.0.1", "user1", "password1");
$serializedConnection = serialize($connection);
print_r($serializedConnection);
unset($connection);
$connection = unserialize($serializedConnection);
print_r($connection);

/*
Constructor called
connect() called
__serialize() called
O:10:"Connection":2:{s:16:"connectionString";s:15:"mysql:127.0.0.1";s:11:"credentials";a:2:{s:8:"username";s:5:"user1";s:8:"password";s:9:"password1";}}Destructor called
close() called
__unserialize() called
Connection Object
(
    [link:protected] =>
    [connectionString:Connection:private] => mysql:127.0.0.1
    [username:Connection:private] => user1
    [password:Connection:private] => password1
    [lastActionTimeStamp:Connection:private] =>
)
Destructor called
close() called
*/
