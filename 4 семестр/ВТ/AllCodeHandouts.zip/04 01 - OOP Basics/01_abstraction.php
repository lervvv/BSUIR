<?php

class Math
{
    public static function getMedian(array $inputNumbersArray): float|int
    {
        sort($inputNumbersArray, SORT_NUMERIC);
        $inputNumbersArrayCount = count($inputNumbersArray);
        $centralElementIndex = floor($inputNumbersArrayCount / 2);
        if ($inputNumbersArrayCount & 1) {
            return $inputNumbersArray[$centralElementIndex];
        } else {
            return ($inputNumbersArray[$centralElementIndex - 1] +
                    $inputNumbersArray[$centralElementIndex]) / 2;
        }
    }
}

$testArrayOne = [3, 1, 8];
echo "MedianOne = " . Math::getMedian($testArrayOne) . "\n";
// MedianOne = 3

$testArrayTwo = [3, 1, 8, 4];
echo "MedianTwo = " . Math::getMedian($testArrayTwo) . "\n";
// MedianTwo = 3.5