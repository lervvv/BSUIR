<?php

class StringsManipulator {
    protected $currentString;

    public function __construct(string $initialString) {
        $this->currentString = $initialString;
    }

    public function getLengthInBytes() : int {
        return strlen($this->currentString);
    }

    public function getLengthInSymbols() : int {
        return strlen($this->currentString);
    }
}

class UTF8StringsManipulator extends StringsManipulator {

    public function getLengthInSymbols() : int {
        return mb_strlen($this->currentString, 'UTF8');
    }
}

$singleByteString = new StringsManipulator('Test');
echo 'singleByteString bytes = ' . $singleByteString->getLengthInBytes() . "\n"; // 4
echo 'singleByteString symbols = ' . $singleByteString->getLengthInSymbols() . "\n"; // 4

$UTF8String = new UTF8StringsManipulator('Тест');
echo 'UTF8String bytes = ' . $UTF8String->getLengthInBytes() . "\n"; // 8
echo 'UTF8String symbols = ' . $UTF8String->getLengthInSymbols() . "\n"; // 4