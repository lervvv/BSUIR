<?php

class URL
{
    public const STATUS_NOT_INITIALIZED = 0b0000;
    public const STATUS_URI_SET = 0b0001;
    public const STATUS_REQUEST_COMPLETED = 0b0010;

    private $currentStatus = self::STATUS_NOT_INITIALIZED;
    private $currentURI = '';

    public function setURI(string $URI): bool
    {
        if (filter_var($URI, FILTER_VALIDATE_URL)) {
            $this->currentURI = $URI;
            $this->currentStatus = $this->currentStatus | self::STATUS_URI_SET;
            return true;
        } else {
            return false;
        }
    }

    public function getStatus() : int {
        return $this->currentStatus;
    }
}

$url = new URL;
$url->setURI('https://google.com');
echo "URL status: " . $url->getStatus();
// URL status: 1