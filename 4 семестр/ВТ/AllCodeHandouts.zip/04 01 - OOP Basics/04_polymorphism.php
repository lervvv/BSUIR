<?php

abstract class Connection {
    private $uniqueId;

    public function __construct(){
        $this->uniqueId = uniqid();
    }

    public function getUniqueId(): string
    {
        return $this->uniqueId;
    }
}

class HttpConnection extends Connection {
    public function connect() {}
}

class HttpsConnection extends Connection {
    public function connect() {}
}

class FtpConnection extends Connection {
    public function connect() {}
}

class ConnectionManager{
    private $connectionsPool = [];

    public function addActiveConnection(Connection $connection) {
        $this->connectionsPool[$connection->getUniqueId()] = $connection;
        $this->connectionsPool[$connection->getUniqueId()]->connect();
    }
}