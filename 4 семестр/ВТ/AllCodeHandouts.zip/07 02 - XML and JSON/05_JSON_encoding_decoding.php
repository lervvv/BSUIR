<?php

// Encoding
$data = array(
    'MP123456' => array('givenName' => 'John', 'familyName' => 'Smith'),
    'MP567890' => array('givenName' => 'Jane', 'familyName' => 'Smith')
);
echo json_encode($data) . "\n\n";

// Encoding again
$message = array(
    'message' => array('from' => 'John', 'to' => 'Jack', 'header' => 'Reminder', 'text' => 'Don\'t forget to call the Customer!')
);
echo json_encode($message) . "\n\n";

// Decoding
$json = file_get_contents("05_JSON_encoding_decoding.json");
print_r(json_decode($json, true));