<?php

// Get XML data, parse it to a PHP array
$xmlData = simplexml_load_file('http://127.0.0.1/06_server.php?xml=true');
$jsonData = json_encode($xmlData);
$xmlArray = json_decode($jsonData, true);
print_r($xmlArray);

// Get JSON data, parse it to a PHP array
$json = file_get_contents('http://127.0.0.1/06_server.php');
print_r(json_decode($json, true));