<?php

// Array for parsed and converted XML storage 
$xmlArray = array();

// "Stack" for temporary storage of nested elements
$xmlStack = array();

// Reference to a parent element
// (to eliminate "false nested elements")
$xmlParent = null;

// Reaction to an element beginning
function elementStart($parser, $name, $attributes)
{
    // TODO: try rewriting this without $GLOBALS :)

    // Let's put the i-th element (and its "parameters") to array
    $index = count($GLOBALS['xmlArray']);
    $GLOBALS['xmlArray'][$index] = array();
    $GLOBALS['xmlArray'][$index]['name'] = $name;
    if (count($attributes) > 0) {
        $GLOBALS['xmlArray'][$index]['attributes'] = $attributes;
    }

    // Let's put the current value into "stack" and "switch" the main array
    // to the just created array of nested elements
    // (this is a king of recursion emulation)
    $GLOBALS['xmlArray'][$index]['children'] = array();
    $GLOBALS['xmlStack'][count($GLOBALS['xmlStack'])] = &$GLOBALS['xmlArray'];
    $GLOBALS['xmlParent'] = &$GLOBALS['xmlArray'][$index];
    $GLOBALS['xmlArray'] = &$GLOBALS['xmlArray'][$index]['children'];
}

// Reaction to an element ending
function elementEnd($parser, $name)
{
    // Let's restore the main array value from the "stack"
    // removing all now unnecessary data
    $GLOBALS['xmlArray'] = &$GLOBALS['xmlStack'][count($GLOBALS['xmlStack']) - 1];
    unset($GLOBALS['xmlStack'][count($GLOBALS['xmlStack']) - 1]);

    // Here's the situation when "a nested element" was an element value for real,
    // we move it to the ['value'] and delete ['children'] subtree 
    if ((isset($GLOBALS['xmlParent']['children'])) &&
        (count($GLOBALS['xmlParent']['children']) == 1) &&
        (isset($GLOBALS['xmlParent']['children']['value']))) {
        $GLOBALS['xmlParent']['value'] = $GLOBALS['xmlParent']['children']['value'];
        unset($GLOBALS['xmlParent']['children']);
    }

}

// Reaction to a characters sequence (elements' values in our case)
function characterData($parser, $data)
{
    $data = trim($data);
    if (strlen($data) > 0) {
        $GLOBALS['xmlArray']['value'] = $data;
    }
}

// Reaction to "anything else" (comments in our case)
function default_data($parser, $data)
{
    $data = trim($data);
    if (substr($data, 0, 4) == '<!--') {
        $data = trim(substr($data, 4, strlen($data) - 7));
        $index = count($GLOBALS['xmlArray']);
        $GLOBALS['xmlArray'][$index]['name'] = 'comment';
        $GLOBALS['xmlArray'][$index]['value'] = $data;
    }
}


// Let's create the parser and define handlers
$xmlParser = xml_parser_create();
xml_set_element_handler($xmlParser, "elementStart", "elementEnd");
xml_set_character_data_handler($xmlParser, 'characterData');
xml_set_default_handler($xmlParser, 'default_data');

// Let's turn off case transformation and spaces preservation
xml_parser_set_option($xmlParser, XML_OPTION_CASE_FOLDING, false);
xml_parser_set_option($xmlParser, XML_OPTION_SKIP_WHITE, true);

// Now we may open the file and read it by small pieces
$fd = fopen('04_SAX_usage.xml', "r");
while ($data = fread($fd, 4096)) {
    if (!xml_parse($xmlParser, $data, feof($fd))) {
        exit('XML error [' . xml_error_string(xml_get_error_code($xmlParser)) . '] at line [' . xml_get_current_line_number($xmlParser) . ']');
    }
}
fclose($fd);

xml_parser_free($xmlParser);
print_r($GLOBALS['xmlArray']);