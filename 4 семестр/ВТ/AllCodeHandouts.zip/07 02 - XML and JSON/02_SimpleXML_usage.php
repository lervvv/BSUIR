<?php

// Yes, it's that simple!

// WARNING! Sometimes SimpleXML “looses” some
// elements in complex documents!

$xmlData = simplexml_load_file('02_SimpleXML_usage.xml');
$jsonData = json_encode($xmlData);
$xmlArray = json_decode($jsonData, true);
print_r($xmlArray);