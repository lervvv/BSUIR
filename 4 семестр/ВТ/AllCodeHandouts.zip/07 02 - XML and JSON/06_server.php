<?php

// This "server" returns a table with random columns and rows count
// as XML or as JSON

$tree = new SimpleXMLElement('<table/>');

$rows = mt_rand(1, 5);
$cols = mt_rand(1, 5);

for ($i = 0; $i < $rows; $i++) {
    $row = $tree->addChild('tr');
    for ($j = 0; $j < $cols; $j++) {
        $row->addChild('td', mt_rand(1, 100));
    }
}

if (isset($_GET['xml'])) {
    header("Content-type: application/xml");
    echo $tree->asXML();
} else {
    header("Content-type: text/plain");
    echo json_encode($tree);
}