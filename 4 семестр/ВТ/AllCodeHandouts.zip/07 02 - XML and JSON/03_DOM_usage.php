<?php

function domToArray($element)
{
    $result = array();

    // Extracting attributes (if any)
    if ($element->hasAttributes()) {
        foreach ($element->attributes as $attribute) {
            $result[$attribute->name] = $attribute->value;
        }
    }

    // Defining element type:
    // we need XML_ELEMENT_NODE, XML_TEXT_NODE,
    // XML_DOCUMENT_NODE, XML_DOCUMENT_TYPE_NODE 
    switch ($element->nodeType) {

        // The document itself
        case XML_DOCUMENT_NODE:
            foreach ($element->childNodes as $subelement) {
                $result[$subelement->nodeName] = domToArray($subelement);
            }
            break;

        // Document elements
        case XML_ELEMENT_NODE:
            
            // Here's some simplification, we suppose that if an element has only one
            // subelement -- that subelement is the value of an element
            if ($element->childNodes->length == 1) {
                $result['value'] = $element->nodeValue;
            } else {
                $elementCount = 2; // In case of several elements with the same names
                $commentCount = 2; // in case of several comments
                foreach ($element->childNodes as $subelement) {
                    // TODO: remove this in case of documents with text blocks
                    if ($subelement->nodeName == '#text') {
                        continue;
                    }

                    // Extracting comments
                    if ($subelement->nodeName == '#comment') {
                        if (!isset($result['comment'])) {
                            $result['comment'] = $subelement->nodeValue;
                        } else {
                            $result['comment' . ($commentCount++)] = $subelement->nodeValue;
                        }
                        continue;
                    }

                    // Processing elements
                    if (!isset($result[$subelement->nodeName])) {
                        $result[$subelement->nodeName] = domToArray($subelement);
                    } else {
                        $result[$subelement->nodeName . ($elementCount++)] = domToArray($subelement);
                    }
                }
            }
            break;

        // Element text part (element value in our simplified approach)
        case XML_TEXT_NODE:
            $result['value'] = $element->nodeValue;
            break;

        // <!DOCTYPE ...>
        case XML_DOCUMENT_TYPE_NODE:
            // We don't store it in the resulting array
            break;

        // Comments
        case XML_COMMENT_NODE:
            $result['comment'] = $element->nodeValue;
            break;

        // TODO: add other elemnts here
        default:
            exit('Unsupported element type: ' . $element->nodeType);
    }
    return $result;
}

$data = file_get_contents('03_DOM_usage.xml');
$xml = new DOMDocument();
$xml->loadXML($data);
$xmlArray = domToArray($xml);
print_r($xmlArray);