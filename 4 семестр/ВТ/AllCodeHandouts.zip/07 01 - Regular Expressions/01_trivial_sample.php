<?php

$text = 'Some date is 12.10.2005, and some number is 890.';
preg_match_all("/\d/", $text, $result);
print_r($result);

/* Array
  ([0] => Array ([0] => 1, [1] => 2, [2] => 1, [3] => 0, [4] => 2,
                 [5] => 0, [6] => 0, [7] => 5, [8] => 8, [9] => 9,  [10] => 0))
*/

/*
Other valid delimiters samples:
/foo bar/
#^[^0-9]$#
+php+
%[a-zA-Z0-9_-]%
*/