<?php

// 1) “Does the text contain at least one three-digit number?”
$text = "This is some text with two numbers: 1234 and 567.";
if (preg_match("/\b\d{3}\b/", $text)) {
    echo "There is a three-digit number in the text.\n";
}

// 2) “Is the string a three-digit number?”
$text = "890";
if (preg_match("/^\d{3}$/", $text)) {
    echo "The string is a three-digit number.\n";
}

// 3) "Show all two-digits numbers that are at the beginning or at the end of a line".
$text = "12 34 56
78 90 21";
preg_match_all("/^\d{2}\b|\b\d{2}(?:\r?)$/m", $text, $result);
print_r($result);
// Array ([0] => 12, [1] => 56, [2] => 78, [3] => 21)

// 4) "Extract parts of dates in [D]D.[M]M.[YY]YY format."
$text = "1.7.99, 10.05.2001";
preg_match_all("/\b(\d{1,2})\.(\d{1,2})\.(\d{4}|\d{2})\b/", $text, $result, PREG_SET_ORDER);
print_r($result);
preg_match_all("/\b([0123]?\d)\.([01]?\d)\.((?:19|20)\d{2}|\d{2})\b/", $text, $result, PREG_SET_ORDER);
print_r($result);
// [0] => Array ([0] => 1.7.99, [1] => 1, [2] => 7, [3] => 99)
// [1] => Array ([0] => 10.05.2001, [1] => 10, [2] => 05, [3] => 2001)

// 5) "Delete all italic text."
$text = "Some <i>italic</i> words <I>and
even</I> more...";
echo $text = preg_replace("/<i>.*<\/i>/imsU", "", $text);
// Some  words  more...

// 6) "Mark duplicate words with <b> tag."
$text = "Some words words and even even more...";
echo $text = preg_replace("/(\b[\w']+\b)(\W+)(\b\\1\b)/i", "\\1\\2<b>\\3</b>", $text);
// Some words <b>words</b> and even <b>even</b> more...

// 7) “Is the string a number with ',' or ' ' as a groups separator?”
$test[] = '123456';
$test[] = '123 456';
$test[] = '12 34.56';
$test[] = '12 3 4.56';
$test[] = '1234.56';
$test[] = '1,234.56';
$test[] = '1,234';
foreach ($test as $number) {
    echo $number;
    if (preg_match("/^\d{1,3}([ ,]\d{3})*([.,]\d+)?$/", $number)) {
        echo " is OK\n";
    } else {
        echo " is NOT OK\n";
    }
}
// 123456 is NOT OK
// 123 456 is OK
// 12 34.56 is NOT OK
// 12 3 4.56 is NOT OK
// 1234.56 is NOT OK
// 1,234.56 is OK
// 1,234 is OK

// 8) "Show all product codes (5 digits, 3 letters, at least two sequential letters are in lowercase)."
$text = "12345aBc 12312deF 87654STU 12312Mnk 12312xYZ 45678gtk";
preg_match_all("/\d{5}(?=[A-Z]?[a-z]{2})[A-Za-z]{3}/", $text, $result);
print_r($result);
// Array ([0] => 12312deF, [1] => 12312Mnk, [2] => 45678gtk)

// 9) "Make all integers <b>bold</b> and all doubles <i>italic</i> (and round to one decimal digit)."
$text = "Just 12.233 some 45 text with 12.12.12 some numbers 99.";

function numbers(array $candidate): string
{
    $test = trim($candidate[0], '.');
    if (preg_match("/^\d+$/", $test)) {
        return '<b>' . $test . '</b>';
    } elseif (substr_count($test, '.') == 1) {
        return '<i>' . round($test, 1) . '</i>';
    } else {
        return $candidate[0];
    }
}

echo preg_replace_callback("/\b[\d.-]+\b/", 'numbers', $text);
// Just <i>12.2</i> some <b>45</b> text with 12.12.12 some numbers <b>99</b>.

// 10) "Find all sequences of 'three lowercase letters, three digits' with any quantity of repetitions."
$text = "Some aaa111 text bbb222ccc333 and dd444 and eee55 and fff555";
preg_match_all("/[a-z]{3}\d{3}(?R)?/", $text, $result);
print_r($result);
// Array ([0] => aaa111, [1] => bbb222ccc333, [2] => fff555)
