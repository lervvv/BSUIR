<?php

$text = 'Some date is 12.10.2005.';

// 4) Find all "two-digits sequences" using quantifiers:
preg_match_all("/\d{2}/", $text, $result);
print_r($result);
// Array ([0] => 12, [1] => 10, [2] => 20, [3] => 05)

// 5) Find all "three-digits sequences" using quantifiers:
preg_match_all("/\d{3}/", $text, $result);
print_r($result);
// Array ([0] => 200)

// 6) Find all "2-3-4-digits sequences" using quantifiers:
preg_match_all("/\d{2,4}/", $text, $result);
print_r($result);
// Array ([0] => 12, [1] => 10, [2] => 2005)