<?php

$text = 'Some date is 12.10.2005.';

// 1) Find all digits:
preg_match_all("/\d/", $text, $result);
print_r($result);
// Array ([0] => 1, [1] => 2, [2] => 1, [3] => 0, [4] => 2, [5] => 0, [6] => 0, [7] => 5)

// 2) Find all "two-digits sequences":
preg_match_all("/\d\d/", $text, $result);
print_r($result);
// Array ([0] => 12, [1] => 10, [2] => 20, [3] => 05)

// 3) Find all "three-digits sequences":
preg_match_all("/\d\d\d/", $text, $result);
print_r($result);
// Array ([0] => 200)