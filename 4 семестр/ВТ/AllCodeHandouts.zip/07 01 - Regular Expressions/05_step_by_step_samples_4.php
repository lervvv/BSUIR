<?php

$text = 'Date 1 is 28.02.1995. Date 2 is 2/28/95.';

// 10) Find all dates:
preg_match_all("/\d{2}\.\d{2}\.\d{4}|\d{1,2}\/\d{1,2}\/\d{2}/", $text, $result);
print_r($result);
// Array ([0] => 28.02.1995, [1] => 2/28/95)