<?php

$text = 'There are item ABC-123 and DEF-789 in the order.';

// 7) Find all item codes:
preg_match_all("/[A-Z]{3}-\d{3}/", $text, $result);
print_r($result);
// Array ([0] => ABC-123, [1] => DEF-789)

// 8) Find all "words":
preg_match_all("/\w+/", $text, $result);
print_r($result);
// Array ([0] => There, [1] => are, [2] => item, [3] => ABC, [4] => 123, [5] => and,
//        [6] => DEF, [7] => 789, [8] => in, [9] => the, [10] => order)

// 9) Find all "word-like-sequences":
preg_match_all("/[\w-]+/", $text, $result);
print_r($result);
// Array ([0] => There, [1] => are, [2] => item, [3] => ABC-123, [4] => and,
//        [5] => DEF-789, [6] => in, [7] => the, [8] => order)