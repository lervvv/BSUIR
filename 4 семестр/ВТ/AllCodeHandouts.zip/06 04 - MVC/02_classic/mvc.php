<?php

require_once('./classes/Model.php');
require_once('./classes/View.php');
require_once('./classes/Controller.php');

$model = new Model();
$controller = new Controller($model);
$view = new View($model, $controller);

echo $view->getNewPage();

