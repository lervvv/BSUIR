<?php

class Model
{
    public const ACTION_SHOW_FORM = 1;
    public const ACTION_PERFORM_OPERATION = 2;

    private int $action;

    public function setAction(int $action): void
    {
        $this->action = $action;
    }

    public function detectOperation(string $operation): string
    {
        switch ($operation) {
            case '+':
                return '+';
                break;
            case '-':
                return '-';
                break;
            case '*':
                return '*';
                break;
            case '/':
                return '/';
                break;
            default:
                return '?';
        }
    }

    public function performSum(float|int $a, float|int $b): float|int
    {
        return $a + $b;
    }

    public function performSub(float|int $a, float|int $b): float|int
    {
        return $a - $b;
    }

    public function performMul(float|int $a, float|int $b): float|int
    {
        return $a * $b;
    }

    public function performDiv(float|int $a, float|int $b): float|int
    {
        return $a / $b;
    }

    public function performMainLogic(array $data): array
    {
        if ($this->action === self::ACTION_SHOW_FORM) {
            return ['a' => '', 'b' => '', 'operation' => '', 'result' => ''];
        } else {
            $operation = $this->detectOperation($data['operation']);
            switch ($operation) {
                case '+':
                    $result = $this->performSum($data['a'], $data['b']);
                    break;
                case '-':
                    $result = $this->performSub($data['a'], $data['b']);
                    break;
                case '*':
                    $result = $this->performMul($data['a'], $data['b']);
                    break;
                case '/':
                    $result = $this->performDiv($data['a'], $data['b']);
                    break;
            }
            return ['a' => $data['a'], 'b' => $data['b'], 'operation' => $data['operation'], 'result' => $result];
        }
    }
}