<?php

// Attention! HTML here is just for the simplicity!
// "In reality" a template engine should be used!
class View
{
    private Model $model;
    private Controller $controller;
    private array $result;

    public function __construct(Model $model, Controller $controller)
    {
        $this->model = $model;
        $this->controller = $controller;
    }

    public function getNewPage() : string
    {
        // View extracts current user input...
        $data = $this->extractData($_POST);

        // ... gets new data for a new page contents ...
        $this->result = $this->model->performMainLogic($data);

        // ... and generates the new page.
        return $this->getForm($this->result['a'], $this->result['b'], $this->result['operation'], $this->result['result']);
    }

    private function getForm(string $a = '', string $b = '', string $operation = '', string $result = ''): string
    {
        $final_text = '<form action="' . $_SERVER['PHP_SELF'] . '" method="post">';
        $final_text .= 'A = <input type="text" name="a" value="' . $a . '" /><br />';
        $final_text .= 'B = <input type="text" name="b" value="' . $b . '" /><br />';
        $final_text .= 'Operation <input type="text" name="operation" value="' . $operation . '" /><br />';
        $final_text .= 'Result: ' . $result . '<br />';
        $final_text .= '<input type="submit" value="Perform" />';
        $final_text .= '</form>';
        return $final_text;
    }

    public function extractData(array $source): array
    {
        $data['a'] = '';
        $data['b'] = '';
        $data['operation'] = '?';
        $data['result'] = '';

        if ((isset($source['a'])) && (strlen($source['a']) > 0)) {
            $data['a'] = (double)($source['a']);
        }

        if ((isset($source['b'])) && (strlen($source['b']) > 0)) {
            $data['b'] = (double)($source['b']);
        }

        if (isset($source['operation'])) {
            $data['operation'] = substr(trim((string)($source['operation'])), 0, 1);
        }

        return $data;
    }
}