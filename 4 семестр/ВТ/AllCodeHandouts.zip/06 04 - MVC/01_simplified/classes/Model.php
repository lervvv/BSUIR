<?php

class Model
{
    public function detectOperation(string $operation) : string
    {
        switch ($operation) {
            case '+':
                return '+';
                break;
            case '-':
                return '-';
                break;
            case '*':
                return '*';
                break;
            case '/':
                return '/';
                break;
            default:
                return '?';
        }
    }

    public function performSum(float|int $a, float|int $b) : float|int
    {
        return $a + $b;
    }

    public function performSub(float|int $a, float|int $b) : float|int
    {
        return $a - $b;
    }

    public function performMul(float|int $a, float|int $b) : float|int
    {
        return $a * $b;
    }

    public function performDiv(float|int $a, float|int $b) : float|int
    {
        return $a / $b;
    }


}