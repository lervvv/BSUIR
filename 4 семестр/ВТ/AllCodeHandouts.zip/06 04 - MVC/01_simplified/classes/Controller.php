<?php

class Controller
{
    public const STATE_INITIAL = 1;
    public const STATE_POSTED = 2;
    public const STATE_ERROR = 4;

    public function detectState() : int
    {
        if (isset($_POST['operation'])) {
            return self::STATE_POSTED;
        } else {
            return self::STATE_INITIAL;
        }

    }


}