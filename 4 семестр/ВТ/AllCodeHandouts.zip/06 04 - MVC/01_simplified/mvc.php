<?php

require_once('./classes/Model.php');
require_once('./classes/View.php');
require_once('./classes/Controller.php');

$model = new Model();
$view = new View();
$controller = new Controller();

// In "more classic approach" this logic should be spread across Controller and/or Model
switch ($controller->detectState()) {
    case Controller::STATE_INITIAL:
        echo $view->getForm();
        break;
    case Controller::STATE_POSTED:
        $data = $view->extractData($_POST);
        $operation = $model->detectOperation($data['operation']);
        if ($operation == '?') {
            echo $view->getForm($data['a'], $data['b'], $data['operation'], $data['result']);
        } else {
            switch ($operation) {
                case '+':
                    $result = $model->performSum($data['a'], $data['b']);
                    break;
                case '-':
                    $result = $model->performSub($data['a'], $data['b']);
                    break;
                case '*':
                    $result = $model->performMul($data['a'], $data['b']);
                    break;
                case '/':
                    $result = $model->performDiv($data['a'], $data['b']);
                    break;
            }
            echo $view->getForm($data['a'], $data['b'], $data['operation'], $result);
        }
        break;
}