<?php

spl_autoload_register(function ($className) {

    // Directory to store classes
    $baseDir = __DIR__ . '/src/';

    // Full fine name
    $fileName = $baseDir . $className . '.php';
    $fileName = str_replace(['\\', '//'], ['/', '/'], $fileName);

    // For debug only!
    echo "This is the class file: [" . $fileName ."]\n";

    // If the file exists, require it
    if (is_file($fileName)) {
        require $fileName;
    }
});

$testObject = new TestClass;
// This is the class file: [D:/PWD_Code_Samples/04 04 - Autoloading, Application Skeleton/src/TestClass.php]