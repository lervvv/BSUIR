<?php

class FormProcessor
{
    private TemplateProcessor $templateProcessor;

    public function __construct(TemplateProcessor $templateProcessor)
    {
        $this->templateProcessor = $templateProcessor;
    }

    public function processForm(): void
    {
        $this->templateProcessor->setPlaceHolderValue("{PHP_SELF}", $_SERVER['PHP_SELF']);

        $message = '';

        $a = (isset($_POST['a'])) ? $_POST['a'] : 0;
        $b = (isset($_POST['b'])) ? $_POST['b'] : 0;
        $f = (isset($_POST['f'])) ? $_POST['f'] : 0;
        $op = (isset($_POST['op'])) ? $_POST['op'] : '';
        $next = (isset($_POST['next'])) ? $_POST['next'] : '';

        switch ($op) {
            case '+':
                $message = 'Result: ' . $a . ' + ' . $b . ' = ' . round(($a + $b), $f) . ' (with ' . $f . ' fraction digits)';
                break;

            case '-':
                $message = 'Result: ' . $a . ' - ' . $b . ' = ' . round(($a - $b), $f) . ' (with ' . $f . ' fraction digits)';
                break;

            case '*':
                $message = 'Result: ' . $a . ' * ' . $b . ' = ' . round(($a * $b), $f) . ' (with ' . $f . ' fraction digits)';
                break;

            case '/':
                $message = 'Result: ' . $a . ' / ' . $b . ' = ' . round(($a / $b), $f) . ' (with ' . $f . ' fraction digits)';
                break;

            default:
                $message = 'Please, select the operation.';
        }

        $this->templateProcessor->setPlaceHolderValue("{MESSAGE}", $message);

        switch ($next) {
            case 'clear':
                $a = '';
                $b = '';
                $f = '';
                $op = '';
                $this->templateProcessor->setPlaceHolderValue("{IS_SAVE_SELECTED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_CLEAR_SELECTED}", "selected=\"selected\"");
                $this->templateProcessor->setPlaceHolderValue("{IS_SURPRISE_SELECTED}", "");
                break;

            case 'surprise':
                $a = mt_rand(1, 999999);
                $b = mt_rand(1, 999999);
                $f = mt_rand(0, 15);
                $op_r = mt_rand(1, 4);
                if ($op_r == 1) {
                    $op = '+';
                }
                if ($op_r == 2) {
                    $op = '-';
                }
                if ($op_r == 3) {
                    $op = '*';
                }
                if ($op_r == 4) {
                    $op = '/';
                }
                $this->templateProcessor->setPlaceHolderValue("{IS_SAVE_SELECTED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_CLEAR_SELECTED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_SURPRISE_SELECTED}", "selected=\"selected\"");
                break;

            case 'save':
                $this->templateProcessor->setPlaceHolderValue("{IS_SAVE_SELECTED}", "selected=\"selected\"");
                $this->templateProcessor->setPlaceHolderValue("{IS_CLEAR_SELECTED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_SURPRISE_SELECTED}", "");
                break;

            default:
                $this->templateProcessor->setPlaceHolderValue("{IS_SAVE_SELECTED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_CLEAR_SELECTED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_SURPRISE_SELECTED}", "");

        }


        switch ($op) {
            case '+':
                $this->templateProcessor->setPlaceHolderValue("{IS_SUM_CHECKED}", "checked=\"checked\"");
                $this->templateProcessor->setPlaceHolderValue("{IS_SUB_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_MUL_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_DIV_CHECKED}", "");
                break;

            case '-':
                $this->templateProcessor->setPlaceHolderValue("{IS_SUM_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_SUB_CHECKED}", "checked=\"checked\"");
                $this->templateProcessor->setPlaceHolderValue("{IS_MUL_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_DIV_CHECKED}", "");
                break;

            case '*':
                $this->templateProcessor->setPlaceHolderValue("{IS_SUM_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_SUB_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_MUL_CHECKED}", "checked=\"checked\"");
                $this->templateProcessor->setPlaceHolderValue("{IS_DIV_CHECKED}", "");
                break;

            case '/':
                $this->templateProcessor->setPlaceHolderValue("{IS_SUM_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_SUB_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_MUL_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_DIV_CHECKED}", "checked=\"checked\"");
                break;

            default:
                $this->templateProcessor->setPlaceHolderValue("{IS_SUM_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_SUB_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_MUL_CHECKED}", "");
                $this->templateProcessor->setPlaceHolderValue("{IS_DIV_CHECKED}", "");
        }

        $this->templateProcessor->setPlaceHolderValue("{A_VALUE}", $a);
        $this->templateProcessor->setPlaceHolderValue("{B_VALUE}", $b);
        $this->templateProcessor->setPlaceHolderValue("{FRAC_VALUE}", $f);

    }
}