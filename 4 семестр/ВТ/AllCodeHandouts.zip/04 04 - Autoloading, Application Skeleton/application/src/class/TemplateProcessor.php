<?php

class TemplateProcessor
{
    private string $templateFileData = "";
    private array $placeHolders = [];

    public function __construct(string $templateFileName)
    {
        if (is_file($templateFileName)) {
            $this->templateFileData = file_get_contents($templateFileName);
        } else {
            throw new Exception('Template file name [' . $templateFileName. '] not found!');
        }
    }

    public function setPlaceHolderValue(string $placeHolderName, string $placeHolderValue) : void
    {
        $this->placeHolders[$placeHolderName] = $placeHolderValue;
    }

    public function setPlaceHolderWithFile(string $placeHolderName, string $templateFileName) : void
    {
        if (is_file($templateFileName)) {
            $this->placeHolders[$placeHolderName] = file_get_contents($templateFileName);
        } else {
            throw new Exception('Template file name [' . $templateFileName. '] not found!');
        }
    }

    public function processTemplate() : string
    {
        foreach ($this->placeHolders as $placeHolderName => $placeHolderValue) {
            $this->templateFileData = str_replace($placeHolderName, $placeHolderValue, $this->templateFileData);
        }

        return $this->templateFileData;
    }
}