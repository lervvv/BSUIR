<?php

spl_autoload_register(function ($className) {
    $baseDir = __DIR__ . '/../src/class/';
    $fileName = $baseDir . $className . '.php';
    $fileName = str_replace(['\\', '//'], ['/', '/'], $fileName);
    if (is_file($fileName)) {
        require $fileName;
    }
});

$templateProcessor = new TemplateProcessor(__DIR__ . '/../resources/templates/index.tpl');
$templateProcessor->setPlaceHolderValue("{YEAR}", date("Y"));
$templateProcessor->setPlaceHolderValue("{MONTH}", date("m"));
$templateProcessor->setPlaceHolderValue("{DAY}", date("d"));
$templateProcessor->setPlaceHolderWithFile("{FORM}", __DIR__ . '/../resources/templates/form.tpl');

$formProcessor = new FormProcessor($templateProcessor);
$formProcessor->processForm();

echo $templateProcessor->processTemplate();