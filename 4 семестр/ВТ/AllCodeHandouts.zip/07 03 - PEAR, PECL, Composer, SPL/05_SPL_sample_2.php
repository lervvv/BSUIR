<?php

// Stack
$stack = new \SplStack();
$stack->push(1);
$stack->push(2);
$stack->push(3);
echo  $stack->pop() . "\n"; // 3
echo  $stack->pop() . "\n"; // 2
echo  $stack->pop() . "\n"; // 1

// Queue
$queue = new \SplQueue();
$queue->enqueue(1);
$queue->enqueue(2);
$queue->enqueue(3);
echo  $queue->dequeue() . "\n"; // 1
echo  $queue->dequeue() . "\n"; // 2
echo  $queue->dequeue() . "\n"; // 3