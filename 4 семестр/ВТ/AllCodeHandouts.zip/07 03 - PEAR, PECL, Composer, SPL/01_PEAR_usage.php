<?php

// This example will only work with appropriate PEAR package installed!

require_once('../../WebSoft/PEAR/pear/Numbers/Words/Locale/en/US.php');
$sourceNumber = 784513245178;
$transformer = new Numbers_Words_Locale_en_US();
echo $finalString = $transformer->toWords($sourceNumber);
// seven hundred eighty-four billion five hundred thirteen million
// two hundred forty-five thousand one hundred seventy-eight