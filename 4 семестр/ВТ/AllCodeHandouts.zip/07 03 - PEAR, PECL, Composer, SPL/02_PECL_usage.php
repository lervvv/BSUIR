<?php

// This example will only work with appropriate PECL extension installed!

$rarFile = rar_open('02_PECL_usage.rar') or exit("Can't open Rar archive");
$entries = rar_list($rarFile);

foreach ($entries as $entry) {
    echo 'Filename: ' . $entry->getName() . "\n";
    echo 'Packed size: ' . $entry->getPackedSize() . "\n";
    echo 'Unpacked size: ' . $entry->getUnpackedSize() . "\n";
}

rar_close($rarFile);

/*
Filename: cat1.bmp
Packed size: 187513
Unpacked size: 327414
Filename: cat2.bmp
Packed size: 1419119
Unpacked size: 2160054
Filename: cat3.bmp
Packed size: 1154682
Unpacked size: 2107254
*/