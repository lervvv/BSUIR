<?php

// A simple recursive directory traverser

$directory = new \RecursiveDirectoryIterator("../");
$iterator = new \RecursiveIteratorIterator($directory);
foreach ($iterator as $info) {
    if ($info->getType() === 'file') {
        echo $info->getBasename() . " = " . $info->getSize() . "\n";
    }
}

// 03_php_comments.php = 238
// 04_php_case_sensitivity.php = 33
// 05_variables_declaration.php = 438
// ...