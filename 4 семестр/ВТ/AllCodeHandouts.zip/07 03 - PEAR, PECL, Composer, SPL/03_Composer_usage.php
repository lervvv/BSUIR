<?php

// This example will only work after you performed actions described in PDF handouts!

require 'vendor/autoload.php';

$progressBar = new \ProgressBar\Manager(0, 10);

for ($i = 0; $i <= 10; $i++) {
    $progressBar->update($i);
    sleep(1);
}

// 4/10 [====================>-------------------------------] 40.00% 00:00:06