<?php

if (is_file('application.phar')) {
    unlink('application.phar');
}

if (Phar::canWrite()) {
    $pharBuilder = new Phar('application.phar', 0, 'application.phar');
    $pharBuilder = $pharBuilder->convertToExecutable(Phar::PHAR);

    // Start creating phar
    $pharBuilder->startBuffering();

    // Add the whole application at once
    $pharBuilder->buildFromDirectory('./application');

    // Set entry point
    $pharBuilder->setStub($pharBuilder->createDefaultStub('index.php', 'index.php'));

    // Done
    $pharBuilder->stopBuffering();
}