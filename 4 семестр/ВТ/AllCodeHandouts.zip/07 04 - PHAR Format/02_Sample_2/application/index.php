<?php
echo file_get_contents('./html/html1.html');