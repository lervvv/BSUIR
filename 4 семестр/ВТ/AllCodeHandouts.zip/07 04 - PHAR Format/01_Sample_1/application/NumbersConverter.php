<?php

$supportedLocales = "Supported locales:\n" .
    "en_100 (Donald Knuth system), en_GB (British English), en_IN (Indian English), en_US (American English),\n" .
    "es_AR (Argentinian Spanish), es_MX (Mexican Spanish), es_VE (Spanish),\n" .
    "fr_BE (Belgium French),\n" .
    "hu_HU (Hungarian),\n" .
    "it_IT (Italian),\n" .
    "pt_BR (Brazilian Portuguese),\n" .
    "ro_RO (Romanian),\n" .
    "tr_TR (Turkish),\n" .
    "bg (Bulgarian),\n" .
    "cs (Czech),\n" .
    "de (German),\n" .
    "dk (Danish),\n" .
    "es (Castellano Spanish),\n" .
    "et (Estonian),\n" .
    "fr (French),\n" .
    "he (Hebrew),\n" .
    "id (Indonesian),\n" .
    "lt (Lithuanian),\n" .
    "lv (Latvian),\n" .
    "nl (Dutch),\n" .
    "pl (Polish),\n" .
    "ru (Russian),\n" .
    "sv (Swedish),\n" .
    "ua (Ukrainian)\n";

if ($argc < 3) {
    exit("USAGE: php NumbersConverter.phar Locale IntegerNumber\n" . $supportedLocales);
}

$locale = $argv[1];
$classFileName = 'Numbers/Words/Locale/' . preg_replace("/[^a-zA-Z]/", "/", $locale) . '.php';
if (!is_file($classFileName)) {
    exit("Locale [" . $locale . "] not supported.\n" . $supportedLocales);
}

$number = $argv[2];
if (!preg_match("/^\d+$/", $number)) {
    exit("Sorry, the number [" . $number . "] is not an integer.");
}

$numberInt = (int)$number;
if ($numberInt > PHP_INT_MAX) {
    exit("Sorry, the number [" . $number . "] is too big.");
}

require_once($classFileName);
$className = str_replace(['/', '.php'], ['_', ''], $classFileName);
$transformer = new $className;
echo $transformer->toWords($numberInt);