<?php

if (is_file('NumbersConverter.phar')) {
    unlink('NumbersConverter.phar');
}

if (Phar::canWrite()) {
    $pharBuilder = new Phar('NumbersConverter.phar', 0, 'NumbersConverter.phar');
    $pharBuilder = $pharBuilder->convertToExecutable(Phar::PHAR);

    // Start creating phar
    $pharBuilder->startBuffering();

    // Add the whole application at once
    $pharBuilder->buildFromDirectory('./application');

    // Set entry point
    $pharBuilder->setStub($pharBuilder->createDefaultStub('NumbersConverter.php', 'NumbersConverter.php'));

    // Done
    $pharBuilder->stopBuffering();
}