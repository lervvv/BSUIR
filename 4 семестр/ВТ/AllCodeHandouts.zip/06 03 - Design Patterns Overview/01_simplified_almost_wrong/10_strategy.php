<?php

abstract class BeautifulTextMaker
{
    abstract public function beautifyText(string $text) : string;
}

class BoldTextMaker extends BeautifulTextMaker
{
    public function beautifyText(string $text) : string
    {
        return '<b>' . $text . '</b>';
    }
}

class ItalicTextMaker extends BeautifulTextMaker
{
    public function beautifyText(string $text) : string
    {
        return '<i>' . $text . '</i>';
    }
}

class UnderlinedTextMaker extends BeautifulTextMaker
{
    public function beautifyText(string $text) : string
    {
        return '<u>' . $text . '</u>';
    }
}

class TextProcessor
{
    private BeautifulTextMaker $beautifulTextMaker;

    public function __construct(BeautifulTextMaker $beautifulTextMaker)
    {
        $this->beautifulTextMaker = $beautifulTextMaker;
    }

    public function processText(string $text)
    {
        return $this->beautifulTextMaker->beautifyText($text);
    }

}


$boldTextProcessor = new TextProcessor(new BoldTextMaker);
echo $boldTextProcessor->processText('Bold') . "\n";

$italicTextProcessor = new TextProcessor(new ItalicTextMaker);
echo $italicTextProcessor->processText('Italic') . "\n";

$underlinedTextProcessor = new TextProcessor(new UnderlinedTextMaker);
echo $underlinedTextProcessor->processText('Underlined') . "\n";