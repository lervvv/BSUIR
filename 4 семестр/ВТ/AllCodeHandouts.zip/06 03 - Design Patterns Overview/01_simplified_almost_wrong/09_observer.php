<?php

class Actor
{
    private $observers = [];

    public function performAction(string $action): void
    {
        echo "Actor: I'm doing " . $action . "!\n";
        $this->notifyObservers($action);
    }

    public function addObserver(Observer $observer)
    {
        $this->observers[] = $observer;
    }

    private function notifyObservers(string $action)
    {
        foreach ($this->observers as $observer) {
            $observer->reactToObservableAction($action);
        }
    }

}

abstract class Observer
{
    abstract public function reactToObservableAction(string $action);
}

class CuriousObserver extends Observer
{
    public function reactToObservableAction(string $action)
    {
        echo "Hmm... I'm curious! Nice " . $action . "!\n";
    }
}

class AttentiveObserver extends Observer
{
    public function reactToObservableAction(string $action)
    {
        echo "Hmm... I'm attentive! Nice " . $action . "!\n";
    }
}

$actor = new Actor();
$curiousObserver = new CuriousObserver();
$attentiveObserver = new AttentiveObserver();

$actor->addObserver($curiousObserver);
$actor->addObserver($attentiveObserver);

$actor->performAction('something');