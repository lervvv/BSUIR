<?php

abstract class WritingFactory
{
    abstract public function createTool(): Tool;

    abstract public function createSurface(): Surface;
}

class OfficeWriting extends WritingFactory
{

    public function createTool(): Tool
    {
        return new Pen;
    }

    public function createSurface(): Surface
    {
        return new Plastic;
    }

}

class HomeWriting extends WritingFactory
{

    public function createTool(): Tool
    {
        return new Pencil;
    }

    public function createSurface(): Surface
    {
        return new Paper;
    }
}

abstract class Tool
{
}

class Pen extends Tool
{
    public function write()
    {
        return "Pen";
    }
}

class Pencil extends Tool
{
    public function write()
    {
        return "Pencil";
    }
}

abstract class Surface
{
}

class Paper extends Surface
{
    public function writeWith(Tool $tool)
    {
        echo "Writing on Paper with " . $tool->write() . "\n";
    }
}

class Plastic extends Surface
{
    public function writeWith(Tool $tool)
    {
        echo "Writing on Plastic with " . $tool->write() . "\n";
    }
}

class CreativityProcess
{
    private $tool;
    private $surface;

    public function __construct(WritingFactory $writingFactory)
    {
        $this->tool = $writingFactory->createTool();
        $this->surface = $writingFactory->createSurface();
    }

    public function write() {
        $this->surface->writeWith($this->tool);
    }
}

$officeCreativity = new CreativityProcess(new OfficeWriting());
$officeCreativity->write();

$homeCreativity = new CreativityProcess(new HomeWriting());
$homeCreativity->write();