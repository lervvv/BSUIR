<?php

class Clock
{
    public function getTime() : int
    {
        return time();
    }
}

class HumanClock extends Clock
{

    public function getHumanTime() : string
    {
        return date('H:i:s', $this->getTime());
    }

}

$originalClock = new Clock();
echo $originalClock->getTime() . "\n";

$wrappedClock = new HumanClock();
echo $wrappedClock->getHumanTime() . "\n";
