<?php

// Disclaimer! This is NOT a tree-builder or math formula builder!
// It does NOT follow any specific rules.
// It just shows the idea of "composing a component with another components"!
class BracketedExpression
{
    protected $subexpressions = [];

    public function __construct(string|BracketedExpression $subexpression)
    {
        $this->subexpressions[] = $subexpression;
    }

    public function add(string|BracketedExpression $subexpression): void
    {
        $this->subexpressions[] = $subexpression;
    }

    public function render(): string
    {
        $output = "";

        foreach ($this->subexpressions as $subexpression) {
            if ($subexpression instanceof BracketedExpression) {
                $output .= '{' . $subexpression->render() . '}';
            } else {
                $output = '{' . $output . $subexpression . '}';
            }

        }

        return $output;
    }
}

$bracketedExpression = new BracketedExpression('A,B');
$bracketedExpression->add('X');
$bracketedExpression->add(new BracketedExpression('C,D,E'));
echo $bracketedExpression->render();