<?php

class StringIterator implements Iterator
{
    private string $stringData;
    private int $stringPosition;

    public function __construct(string $stringData)
    {
        $this->stringData = $stringData;
        $this->stringPosition = 0;
    }

    public function current(): mixed
    {
        if ($this->stringPosition < strlen($this->stringData)) {
            return $this->stringData[$this->stringPosition];
        } else {
            return null;
        }
    }

    public function next(): void
    {
        $this->stringPosition++;
    }

    public function key(): mixed
    {
        return $this->stringPosition;
    }

    public function valid(): bool
    {
        if ($this->stringPosition < strlen($this->stringData)) {
            return true;
        } else {
            return false;
        }
    }

    public function rewind(): void
    {
        $this->stringPosition = 0;
    }
}

$stringIterator = new StringIterator('ABCDE');
foreach ($stringIterator as $position => $letter) {
    echo "[" . $position . "] = [" . $letter . "]\n";
}