<?php

class FileWriter
{
    private $fileResource;

    public function openFile(string $fileName): void
    {
        $this->fileResource = fopen($fileName, 'wb');
    }

    public function writeToFile(string $data): void
    {
        fputs($this->fileResource, $data);
    }

    public function closeFile(): void
    {
        fclose($this->fileResource);
    }
}


class ProxiedFileWriter
{
    private FileWriter $fileWriter;
    private string $dataToWrite = '';

    public function openFile(string $fileName): void
    {
        $this->fileWriter = new FileWriter();
        $this->fileWriter->openFile($fileName);
    }

    public function writeToFile(string $data): void
    {
        $this->dataToWrite .= $data;
        if (strlen($this->dataToWrite) < 10) {
            echo "Too few data. Add more.\n";
        } else {
            $this->fileWriter->writeToFile($this->dataToWrite);
            $this->dataToWrite = '';
            echo "\nWritten!\n";
        }
    }

    public function closeFile(): void
    {
        $this->fileWriter->closeFile();
    }
}

$proxiedFileWriter = new ProxiedFileWriter();
$proxiedFileWriter->openFile('php://stdout');
$proxiedFileWriter->writeToFile('ABC');
$proxiedFileWriter->writeToFile('DEFG');
$proxiedFileWriter->writeToFile('HIJK');