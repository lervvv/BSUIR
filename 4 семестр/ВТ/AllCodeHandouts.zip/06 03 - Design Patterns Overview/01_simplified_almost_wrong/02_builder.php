<?php

class BuildablePictureElement
{
    private string $src;
    private string $alt;
    private int $width;
    private int $height;

    // All setters should return the object itself
    // to allow chaining: $img->setSrs(...)->setAlt(...)

    public function setSrc(string $src): BuildablePictureElement
    {
        $this->src = $src;
        return $this;
    }

    public function setAlt(string $alt): BuildablePictureElement
    {
        $this->alt = $alt;
        return $this;
    }

    public function setWidth(int $width): BuildablePictureElement
    {
        $this->width = $width;
        return $this;
    }

    public function setHeight(int $height): BuildablePictureElement
    {
        $this->height = $height;
        return $this;
    }

    public function getImg(): string
    {
        return '<img src="' . $this->src . '" alt="' . $this->alt . '" width="' . $this->width . '" height="' . $this->height . '">';
    }

}

echo $img = (new BuildablePictureElement())
    ->setSrc('1.jpg')
    ->setAlt('Picture')
    ->setHeight(10)
    ->setWidth(20)
    ->getImg();

