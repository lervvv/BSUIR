<?php

abstract class Writer
{
    public const COLOR_BLUE = 1;
    public const COLOR_RED = 2;
    abstract protected function getWritingTool(?string $color = self::COLOR_BLUE): WritingTool;
}

abstract class WritingTool
{

}

class BluePen extends WritingTool
{
    public function write()
    {
        echo "BluePen\n";
    }

}

class RedPen extends WritingTool
{
    public function write()
    {
        echo "RedPen\n";
    }

}

class Pencil extends WritingTool
{
    public function write()
    {
        echo "Pencil\n";
    }
}

class PenWriter extends Writer
{
    public function write(?string $color = Writer::COLOR_BLUE): void
    {
        $writingTool = $this->getWritingTool($color);
        $writingTool->write();
    }

    protected function getWritingTool(?string $color = Writer::COLOR_BLUE): WritingTool
    {
        if ($color == Writer::COLOR_BLUE) {
            return new BluePen();
        } else {
            return new RedPen();
        }
    }
}

class PencilWriter extends Writer
{
    public function write(): void
    {
        $writingTool = $this->getWritingTool();
        $writingTool->write();
    }

    protected function getWritingTool(?string $color = Writer::COLOR_BLUE): WritingTool
    {
        return new Pencil();
    }
}

$penWriter = new PenWriter();
$pencilWriter = new PencilWriter();
$penWriter->write(Writer::COLOR_BLUE);
$penWriter->write(Writer::COLOR_RED);
$pencilWriter->write(null);