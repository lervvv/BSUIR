<?php

// The Subject interface describes the interface of a real object.
interface Downloader
{
    public function download(string $url): string;
}

// The Real Subject does the real job, albeit not in the most efficient way.
// When a client tries to download the same file for the second time, our
// downloader does just that, instead of fetching the result from cache.
class SimpleDownloader implements Downloader
{
    public function download(string $url): string
    {
        echo "Downloading a file from the Internet.\n";
        $result = file_get_contents($url);
        echo "Downloaded bytes: " . strlen($result) . "\n";

        return $result;
    }
}

// The Proxy class is our attempt to make the download more efficient. It wraps
// the real downloader object and delegates it the first download calls. The
// result is then cached, making subsequent calls return an existing file
// instead of downloading it again.
// Note that the Proxy MUST implement the same interface as the Real Subject.
class CachingDownloader implements Downloader
{
    private $downloader;
    private $cache = [];

    public function __construct(SimpleDownloader $downloader)
    {
        $this->downloader = $downloader;
    }

    public function download(string $url): string
    {
        if (!isset($this->cache[$url])) {
            echo "CacheProxy MISS. ";
            $result = $this->downloader->download($url);
            $this->cache[$url] = $result;
        } else {
            echo "CacheProxy HIT. Retrieving result from cache.\n";
        }
        return $this->cache[$url];
    }
}

// The client code may issue several similar download requests. In this case,
// the caching proxy saves time and traffic by serving results from cache.
// The client is unaware that it works with a proxy because it works with
// downloaders via the abstract interface.
function sampleOfProxyUsage(Downloader $subject)
{
    // ...

    $result = $subject->download("http://example.com/");

    // Duplicate download requests could be cached for a speed gain.

    $result = $subject->download("http://example.com/");

    // ...
}

echo "Executing client code with real subject:\n";
$realSubject = new SimpleDownloader();
sampleOfProxyUsage($realSubject);

echo "\n";

echo "Executing the same client code with a proxy:\n";
$proxy = new CachingDownloader($realSubject);
sampleOfProxyUsage($proxy);