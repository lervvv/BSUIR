<?php

class Logger
{
    // The actual singleton's instance almost always resides inside a static field.
    private static Logger $instance;

    // This we'll use for logging.
    private $logResource;

    // Singleton's constructor should not be public.
    // It can be private (or protected, if we want to allow inheritance).
    private function __construct()
    {
        $this->logResource = fopen('php://stdout', 'w');
    }

    // Cloning and unserialization are not permitted for singletons.
    protected function __clone()
    {
    }

    public function __wakeup()
    {
        throw new Exception("Cannot unserialize singleton");
    }

    // The destructor should be public.
    public function __destruct()
    {
        fclose($this->logResource);
    }

    // This method is used to get a Singleton's instance.
    public static function getInstance()
    {
        if (!isset(self::$instance)) {
            // Yes, we may use 'new Logger', still this is more accurate:
            self::$instance = new static();
        }
        return self::$instance;
    }

    // Main business logic :).
    public function logRecord(string $message): void
    {
        $dateAndTime = date('Y.m.d H:i:s');
        fwrite($this->logResource, $dateAndTime . ': ' . $message . "\n");
    }

    // Or we may even simplify the approach (combine object creation and business logic).
    public static function logRecordAtOnce(string $message): void
    {
        $logger = static::getInstance();
        $logger->logRecord($message);
    }

}

// This is how to get an instance of a Singleton.
$loggerOne = Logger::getInstance();

// Let's make sure there is only one instance.
$loggerTwo = Logger::getInstance();

if ($loggerOne === $loggerTwo) {
    $loggerOne->logRecord("It works!");
}

// Simplified approach.
Logger::logRecordAtOnce("Done!");