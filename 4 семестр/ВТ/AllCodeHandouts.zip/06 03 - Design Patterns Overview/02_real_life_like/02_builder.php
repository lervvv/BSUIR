<?php

// All of steps are returning the current builder object to
// allow chaining: $builder->select(...)->where(...)
interface SQLQueryBuilder
{
    public function select(string $table, array $fields): SQLQueryBuilder;

    public function where(string $field, string $value, string $operator = '='): SQLQueryBuilder;

    public function limit(int $start, int $offset): SQLQueryBuilder;

    // ... and so on ...
    public function getSQL(): string;
}

// Each specific Builder corresponds to a specific SQL dialect and may implement
// the builder steps differently from the others.
class MysqlQueryBuilder implements SQLQueryBuilder
{
    protected $query;

    protected function reset(): void
    {
        $this->query = new \stdClass();
    }

    // Build a base SELECT query.
    public function select(string $table, array $fields): SQLQueryBuilder
    {
        $this->reset();
        $this->query->base = "SELECT `" . implode("`, `", $fields) . "` FROM " . '`' . $table . '`';
        $this->query->type = 'select';

        return $this;
    }

    // Add a WHERE condition.
    public function where(string $field, string $value, string $operator = '='): SQLQueryBuilder
    {
        if (!in_array($this->query->type, ['select', 'update', 'delete'])) {
            throw new \Exception("WHERE can only be added to SELECT, UPDATE OR DELETE");
        }
        $this->query->where[] = "`$field` $operator '$value'";

        return $this;
    }

    // Add a LIMIT constraint.
    public function limit(int $start, int $offset): SQLQueryBuilder
    {
        if (!in_array($this->query->type, ['select'])) {
            throw new Exception("LIMIT can only be added to SELECT");
        }
        $this->query->limit = " LIMIT " . $start . ", " . $offset;

        return $this;
    }

    // Get the final query string.
    public function getSQL(): string
    {
        $query = $this->query;
        $sql = $query->base;
        if (!empty($query->where)) {
            $sql .= " WHERE " . implode(' AND ', $query->where);
        }
        if (isset($query->limit)) {
            $sql .= $query->limit;
        }
        $sql .= ";";
        return $sql;
    }
}

// This Builder is compatible with PostgreSQL.
class PostgresQueryBuilder extends MysqlQueryBuilder
{
    // Build a base SELECT query.
    public function select(string $table, array $fields): SQLQueryBuilder
    {
        $this->reset();
        $this->query->base = "SELECT \"" . implode("\", \"", $fields) . "\" FROM " . '"' . $table . '"';
        $this->query->type = 'select';

        return $this;
    }

    // Add a WHERE condition.
    public function where(string $field, string $value, string $operator = '='): SQLQueryBuilder
    {
        if (!in_array($this->query->type, ['select', 'update', 'delete'])) {
            throw new \Exception("WHERE can only be added to SELECT, UPDATE OR DELETE");
        }
        $this->query->where[] = "\"$field\" $operator \"$value\"";

        return $this;
    }


    // PostgreSQL has slightly different LIMIT syntax.
    public function limit(int $start, int $offset): SQLQueryBuilder
    {
        parent::limit($start, $offset);

        $this->query->limit = " LIMIT " . $start . " OFFSET " . $offset;

        return $this;
    }

}

function prepareSqlCode(SQLQueryBuilder $queryBuilder): string
{
    $query = $queryBuilder
        ->select("users", ["name", "email", "password"])
        ->where("age", 18, ">")
        ->where("age", 30, "<")
        ->limit(10, 20)
        ->getSQL();

    return $query;
}


echo "Testing MySQL query builder:\n";
echo prepareSqlCode(new MysqlQueryBuilder());

echo "\n\n";

echo "Testing PostgresSQL query builder:\n";
echo prepareSqlCode(new PostgresQueryBuilder());