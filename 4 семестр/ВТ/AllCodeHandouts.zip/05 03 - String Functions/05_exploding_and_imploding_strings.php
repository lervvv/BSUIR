<?php

$somePathOne = 'c:/dir1/dir2/file.ext';
$partsArray = explode('/', $somePathOne);
print_r($partsArray);
// Array ( [0] => c: [1] => dir1 [2] => dir2 [3] => file.ext )

echo $somePathTwo = implode('\\\\', $partsArray) . "\n";
// c:\\dir1\\dir2\\file.ext

$someCsvLine = 'coumn 1,column 2,column 3';
$columnsArray = str_getcsv($someCsvLine);
print_r($columnsArray);
// Array ( [0] => coumn 1 [1] => column 2 [2] => column 3 )

$someLineWithGetParameters = 'a=99&b=55&c=1';
parse_str($someLineWithGetParameters, $parsedGetParameters);
print_r($parsedGetParameters);
// Array ( [a] => 99 [b] => 55 [c] => 1 )

$someLongString = 'This is a long string';
echo wordwrap($someLongString, 5, '<br>', false) . "\n";
// This<br>is a<br>long<br>string
echo wordwrap($someLongString, 5, '<br>', true) . "\n";
// This<br>is a<br>long<br>strin<br>g
