<?php

echo '[' . trim('   Just a test     ') . ']' . "\n";  // [Just a test]
echo '[' . ltrim('   Just a test     ') . ']'  . "\n"; // [Just a test     ]
echo '[' . rtrim('   Just a test     ') . ']' . "\n"; // [   Just a test]

// You may even define your own set of characters to be trimmed
echo '[' . trim('!!!   Just a test  !!!  ', "! \n\r\t\v\x00") . ']' . "\n";  // [Just a test]

