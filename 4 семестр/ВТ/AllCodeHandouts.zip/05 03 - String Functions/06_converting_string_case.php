<?php

echo strtolower('just a TEST string') . "\n"; // just a test string
echo strtoupper('just a TEST string') . "\n"; // JUST A TEST STRING

echo lcfirst('JUST a TEST string') . "\n"; // jUST a TEST string
echo ucfirst('just a TEST string') . "\n"; // Just a TEST string

echo ucwords('just a TEST string') . "\n"; // Just A TEST String