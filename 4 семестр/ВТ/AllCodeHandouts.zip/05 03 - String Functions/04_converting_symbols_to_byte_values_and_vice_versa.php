<?php

echo ord('A') . "\n"; // 65
echo chr(65) . "\n"; // A