<?php

$userFilename = "/../../etc/passwd";
echo $safeFilename = sha1($userFilename . microtime(true) . mt_rand(1000000, 9999999));
// 139596efa322fdaeea970ad153b4d2a0a5fbb455