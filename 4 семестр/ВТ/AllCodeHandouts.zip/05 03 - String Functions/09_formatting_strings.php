<?php

echo number_format(123456.78, 3) . "\n"; // 123,456.780
echo number_format(123456.78, 3, '.', '\'') . "\n"; // 123'456.780

echo str_pad('Test', 10, '*', STR_PAD_RIGHT) . "\n"; // Test******
echo str_pad('Test', 10, '*', STR_PAD_LEFT) . "\n";  // ******Test
echo str_pad('Test', 10, '*', STR_PAD_BOTH) . "\n";  // ***Test***

echo str_repeat('+-', 5) . "\n"; // +-+-+-+-+-

echo str_shuffle('ABCDEF') . "\n"; // ABEFCD

echo strrev('ABCDEF') . "\n"; // FEDCBA