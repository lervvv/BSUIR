<?php

$mysqli = new mysqli("127.0.0.1", "user", "password", "db");
$city = "'s-Hertogenbosch";

// This query with escaped $city will work
$query = sprintf("SELECT CountryCode FROM City WHERE name='%s'", $mysqli->real_escape_string($city));
$result = $mysqli->query($query);

// This query will fail, because we didn't escape $city
$query = sprintf("SELECT CountryCode FROM City WHERE name='%s'", $city);
$result = $mysqli->query($query);


$pdo = new PDO('sqlite:/home/user/db.sql3');
$city = "'s-Hertogenbosch";

// This query with escaped $city will work
$query = sprintf("SELECT CountryCode FROM City WHERE name='%s'", $pdo->quote($city));
$result = $pdo->query($query);

// This query will fail, because we didn't escape $city
$query = sprintf("SELECT CountryCode FROM City WHERE name='%s'", $city);
$result = $pdo->query($query);