<?php

echo strlen('Test') . "\n"; // 4
echo mb_strlen('Test', 'UTF8') . "\n"; // 4
echo strlen('Тест') . "\n"; // 8
echo mb_strlen('Тест', 'UTF8') . "\n"; // 4

$stringCharacters = count_chars('test', 1);
print_r($stringCharacters); // Array ( [101] => 1 [115] => 1 [116] => 2 )

echo str_word_count('Just a test'); // 3