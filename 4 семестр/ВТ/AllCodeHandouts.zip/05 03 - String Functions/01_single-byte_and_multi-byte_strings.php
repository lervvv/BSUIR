<?php

$singleByteEncoding = 'Test';
$multiByteEncoding = 'Тест';

echo $singleByteEncoding[2]; // s
echo $multiByteEncoding[2]; // �

$singleByteEncoding[2] = 'z';
$multiByteEncoding[2] = 'z';

echo $singleByteEncoding; // Tezt
echo $multiByteEncoding; // Тz�ст