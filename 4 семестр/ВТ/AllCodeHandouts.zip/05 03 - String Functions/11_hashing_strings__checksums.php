<?php

echo sha1_file($argv[0]);
// 7a44895d0653e048d592d9b00df58215de4046e1