<?php

echo str_replace('BC', '****', 'ABCDEF') . "\n"; // A****DEF
echo str_ireplace('bc', '****', 'ABCDEF') . "\n"; // A****DEF

echo strpos('ABCDEF', 'BC') . "\n";  // 1
echo stripos('ABCDEF', 'bc') . "\n"; // 1

echo strrpos('ABCDEF', 'E') . "\n"; // 4
echo strripos('ABCDEF', 'e') . "\n"; // 4

// Since PHP 8 instead of
if (strpos('string with lots of words', 'words') !== false) { /* ... */ }
// you may use
if (str_contains('string with lots of words', 'words')) { /* ... */ }

// And two more useful functions are available since PHP 8
if (str_starts_with('haystack', 'hay')) { /* true */ }
if (str_ends_with('haystack', 'stack')) { /* true */ }

echo substr_count('this is just a test', 'is') . "\n"; // 2

echo substr('this is just a test', 0, 4) . "\n"; // this