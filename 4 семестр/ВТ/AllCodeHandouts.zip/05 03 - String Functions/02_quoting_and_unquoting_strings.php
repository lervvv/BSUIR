<?php

// All HTML entities processing:
$someString = "<img src='1.png'>";
echo htmlentities($someString) . "\n"; // &lt;img src=&#039;1.png&#039;&gt;
$someString = "&lt;img src=&#039;1.png&#039;&gt;";
echo html_entity_decode($someString) . "\n"; // <img src='1.png'>

// Some HTML entities processing (& “ ‘ < >):
$someString = "<img src='1.png'>";
echo htmlspecialchars($someString) . "\n"; // &lt;img src=&#039;1.png&#039;&gt;
$someString = "&lt;img src=&#039;1.png&#039;&gt;";
echo htmlspecialchars_decode($someString) . "\n"; // <img src='1.png'>

// Regexp string quoting:
$someRegexpInputString = ". \ + * ? [ ^ ] $ ( ) { } = ! < > | : -";
echo preg_quote($someRegexpInputString) . "\n";
// \. \\ \+ \* \? \[ \^ \] \$ \( \) \{ \} \= \! \< \> \| \: \-