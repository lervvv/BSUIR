<?php

$inputImageFileName = '';
$outputImageFileName = '';

// Use 'if' instead!!!
try {
    $inputImageFileName = realpath($argv[1]);
} catch (Exception $e) {
    echo "InputImageFileName is missing!\n";
    echo "USAGE: php image_converter.php InputImageFileName InputImageFileName\n";
    exit(-1);
}

// Use 'if' instead!!!
try {
    $outputImageFileName = realpath($argv[2]);
} catch (Exception $e) {
    echo "OutputImageFileName is missing!\n";
    echo "USAGE: php image_converter.php InputImageFileName InputImageFileName\n";
    exit(-2);
}

// This is ultimate madness. It's like talking in a messenger with yourself... :(
try {
    if (($inputImageFileName == '') || ($outputImageFileName == '')) {
        throw new Exception("USAGE: php image_converter.php InputImageFileName InputImageFileName\n");
    }
} catch (Exception $exception) {
    echo $exception->getMessage();
}