<?php

try {
    // Something that may go wrong...
} catch (ChildException $e) {
    // Reaction to lover-level exception.
} catch (ParentException $e) {
    // Reaction to higher-level exception.
} finally {
    // Some 'final' code that should work
    // no mater, if there was an exception,
    // or if there was not.
}


$linksOnThePage = $page->getAllLinks();

foreach ($linksOnThePage as $url) {
    try {
        $page->setInnerObjectsData($url, $crawler->getDataFromURL($url));
    } catch (HttpException_404) {
        $page->setInnerObjectsStatus($url, 404);
    } catch (HttpException_403) {
        $page->setInnerObjectsStatus($url, 403);
    } catch (HttpException) {
        $page->setInnerObjectsStatus($url, -1);
    } finally {
        $page->incrementInnerObjectsProcessedCount();
    }
}