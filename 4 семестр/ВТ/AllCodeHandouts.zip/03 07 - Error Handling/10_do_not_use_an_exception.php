<?php

if ($argc < 3) {
    echo "USAGE: php image_converter.php InputImageFileName InputImageFileName\n";
    exit(-1);
}