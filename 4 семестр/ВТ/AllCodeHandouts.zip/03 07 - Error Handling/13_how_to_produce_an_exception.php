<?php

// General approach:
if ($somethingIsWrong) {
    throw new Exception("Message");
}

// Since PHP 8 this approach is also available:
$someValue = $someArray['offset'] ?? throw new OffsetDoesNotExist('offset');
