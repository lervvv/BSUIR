<?php

function someFunctionOne(): void
{
    someFunctionTwo('Test');
}

function someFunctionTwo(string $msg): void
{
    print_r(debug_backtrace());
    debug_print_backtrace();
}

someFunctionOne();

/*
Array
(
    [0] => Array
        (
            [file] => D:\PWD_Code_Samples\03 07 - Error Handling\04_debug_backtrace.php
            [line] => 5
            [function] => someFunctionTwo
            [args] => Array
                (
                    [0] => Test
                )

        )

    [1] => Array
        (
            [file] => D:\PWD_Code_Samples\03 07 - Error Handling\04_debug_backtrace.php
            [line] => 14
            [function] => someFunctionOne
            [args] => Array
                (
                )

        )

)
#0 D:\PWD_Code_Samples\03 07 - Error Handling\04_debug_backtrace.php(5): someFunctionTwo('Test')
#1 D:\PWD_Code_Samples\03 07 - Error Handling\04_debug_backtrace.php(14): someFunctionOne()
*/