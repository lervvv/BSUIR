<?php

function customExceptionHandler($exception)
{
    echo 'Exception: ' . $exception->getMessage() . "\n";
}

set_exception_handler('customExceptionHandler');
throw new Exception('TEST');

/*
Exception: TEST
*/

// As we've thrown an exception, the script will be terminated,
// and we'll never get to this line:
restore_exception_handler();
throw new Exception('TEST');