<?php

$someArray = [1, 2, 3];

if (!isset($someArray[999])) {
    // Write a message to a log set be error_log option in php.ini
    error_log('No 999th element in array!', 0);

    // Sand a e-mail to administrator
    error_log('No 999th element in array!', 1, "admin@site.com");

    // Write a message to some log file
    error_log('No 999th element in array!', 3, 'D:/our_error_log.txt');
}