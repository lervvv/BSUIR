<?php

function customErrorHandler($errno, $errstr, $errfile, $errline)
{
    // We just 'convert' any error to an exception
    throw new Exception('Error [' . $errstr . '] (number [' . $errno .']) in [' .
                                            $errfile . '] at line [' . $errline . ']');
}

function customExceptionHandler($exception)
{
    // Here we may use any additional data to make the message more informative:
    error_log(date('Y.m.d H:i:s') . ' Exception: ' . $exception->getMessage() . "\n", 0);
}

set_error_handler('customErrorHandler');
set_exception_handler('customExceptionHandler');

echo $someVariable;
// 2022.01.05 16:20:32 Exception: Error [Undefined variable $someVariable] (number [2]) in [D:\INFO\STORM_WS\PWD_Code_Samples\03 07 - Error Handling\08_big_sample.php] at line [19]