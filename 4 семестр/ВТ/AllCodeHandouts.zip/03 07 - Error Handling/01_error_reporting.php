<?php

// Turns off all error messages (for this particular script execution)

error_reporting(0);

// No more error message here
$someData = file('non_existing_file');