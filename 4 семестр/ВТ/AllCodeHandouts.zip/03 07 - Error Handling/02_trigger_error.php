<?php

$someArray = [1, 2, 3];

if (!isset($someArray[999])) {
    trigger_error('No 999th element in array!', E_USER_ERROR);
}
