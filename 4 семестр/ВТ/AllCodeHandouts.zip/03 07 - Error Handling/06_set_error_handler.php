<?php

function customErrorHandler($errno, $errstr, $errfile, $errline)
{
    echo 'Error #   : ' . $errno . "\n";
    echo 'Error is  : ' . $errstr . "\n";
    echo 'Error file: ' . $errfile . "\n";
    echo 'Error line: ' . $errline . "\n";
}

$oldErrorHandler = set_error_handler('customErrorHandler');
echo $someVariable;
/*
Error #   : 2
Error is  : Undefined variable $someVariable
Error file: D:\PWD_Code_Samples\03 07 - Error Handling\06_set_error_handler.php
Error line: 12
*/

restore_error_handler();
echo $someVariable;
/* Warning: Undefined variable $someVariable in D:\PWD_Code_Samples\03 07 - Error Handling\06_set_error_handler.php on line 21 */