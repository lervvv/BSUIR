<?php

// Let's imagine that this function is in some library you are creating...
function copyFile($sourceFileName, $destinationFileName) : bool
{
    $finalResult = false;

    if (!is_file($sourceFileName)) {
        throw new Exception('Source file [' . $sourceFileName . '] does not exist!');
    }

    // ... Here goes a lot of useful code ...

    return $finalResult;
}

// And this is how someone will use your library...
try {
    copyFile('c:/non_existing_file.ext', 'c:/copy.ext');
} catch (Exception $e) {
    // Some reaction here...
}