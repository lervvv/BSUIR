<?php

$someArray = [1, 2, 3];
echo $someArray[999];
print_r(error_get_last());

/*
Array
(
    [type] => 2
    [message] => Undefined array key 999
    [file] => D:\PWD_Code_Samples\03 07 - Error Handling\03_error_get_last.php
    [line] => 4
)
*/

error_clear_last();
print_r(error_get_last()); // Empty result