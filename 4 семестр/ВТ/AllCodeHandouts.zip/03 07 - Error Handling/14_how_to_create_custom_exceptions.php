<?php

class TypeMissmatchException extends Exception{};

class MathException extends Exception{};

function getAverage($numbers)
{
    if (!is_array($numbers)) {
        throw new TypeMissmatchException('Function getAverage expects first argument to be an array!');
    }

    if (sizeof($numbers) === 0) {
        throw new MathException('Function getAverage expects non empty array!');
    }

    // Useful code here :).
}

$test1 = 'Test';
$test2 = [];
$test3 = [1, 2, 3];

try {
    $avg = getAverage($test1);
} catch (TypeMissmatchException $e) {
    var_dump($e);
} catch (MathException $e) {
    var_dump($e);
}