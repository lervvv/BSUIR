<?php

print_r(file('http://svyatoslav.biz'));
/*
Array
(
    [0] => <!DOCTYPE html>
    [1] => <!--[if IE 7]>
    [2] => <html class="ie ie7" lang="ru-RU">
     ...
)
*/

$archivedFileDescriptor = fopen('zip://./archive.zip#file.txt', 'r');
if ($archivedFileDescriptor) {
    while (!feof($archivedFileDescriptor)) {
        echo fread($archivedFileDescriptor, 8192);
    }
    fclose($archivedFileDescriptor);
}