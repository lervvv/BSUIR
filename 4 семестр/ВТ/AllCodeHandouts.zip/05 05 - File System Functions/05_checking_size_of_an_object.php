<?php

echo filesize('C:/Windows/notepad.exe'). "\n"; // 208384

function getDirectorySize(string $directoryToScan) : int
{
    if (!is_dir($directoryToScan)) {
        throw new Exception('getDirectorySize expects its parameter to be a valid directory path.');
    }

    $totalSize = 0;
    $directoryDescriptor = opendir($directoryToScan);
    if ($directoryDescriptor === false) {
        return 0;
        // Or you may throw an exception instead:
        // throw new Exception('Failed to open [' . $directoryToScan . '].');
    }

    while (false !== ($objectName = readdir($directoryDescriptor))) {
        if (($objectName === '.') || ($objectName === '..')) {
            continue;
        }
        $fullName = realpath($directoryToScan . DIRECTORY_SEPARATOR . $objectName);
        if (is_dir($fullName)) {
            $totalSize += getDirectorySize($fullName);
        } else {
            $totalSize += filesize($fullName);
        }
    }

    closedir($directoryDescriptor);
    return $totalSize;
}

echo getDirectorySize('C:/Program Files'); // 22156607810