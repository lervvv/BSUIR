<?php

// This function NEVER works for directories:
copy("c:/1.txt","d:/2.txt");

// This function MAY work for directories in rare cases:
rename("c:/11.txt","d:/22.txt");

// This function MAY work for directories in rare cases:
unlink("/home/dir/file.ext");

