<?php

echo "Enter something (or press ENTER to exit): \n";
$stdIn = fopen('php://stdin', 'r');
$stdOut = fopen('php://stdout', 'w');
$stdErr = fopen('php://stderr', 'w');
while ($line = trim(fgets($stdIn))) {
    if ($line == '') {
        break;
    }
    fputs($stdOut, 'You\'ve entered: ' . $line . "\n");
    fputs($stdErr, 'Not an error, just for fun: ' . $line . "\n");
}
fclose($stdIn);
echo "OK, exiting...";