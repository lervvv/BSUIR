<?php

// Getting and changing CWD (current working directory):
echo getcwd() . "\n"; // D:\PWD_Code_Samples\05 05 - File System Functions
chdir('c:/');
echo getcwd() . "\n"; // C:\

// Creating and deleting a directory:
mkdir('c:/1');
rmdir('c:/1');