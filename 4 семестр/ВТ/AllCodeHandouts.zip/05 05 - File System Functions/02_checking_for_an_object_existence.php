<?php

if (file_exists('c:/dir1/dir2/some_file.txt')) {
    echo 'Yes';
} else {
    echo 'No';
}