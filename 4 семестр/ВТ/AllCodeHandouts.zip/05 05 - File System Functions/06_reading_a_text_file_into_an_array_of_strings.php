<?php

print_r(file('C:/Windows/System32/drivers/etc/hosts'));
/*
Array
(
    [0] => # Copyright (c) 1993-2009 Microsoft Corp.
    [1] => #
    [2] => # This is a sample HOSTS file used by Microsoft TCP/IP for Windows.
    [3] => #
    [4] => # This file contains the mappings of IP addresses to host names. Each
    [5] => # entry should be kept on an individual line. The IP address should
    ...
)
*/