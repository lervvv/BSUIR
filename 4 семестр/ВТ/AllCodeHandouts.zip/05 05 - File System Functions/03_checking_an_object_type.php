<?php

var_dump(is_file('C:/Windows/notepad.exe')); // bool(true)
var_dump(is_dir('c:/')); // bool(true)
var_dump(is_link('C:/Windows/notepad.exe')); // bool(false)