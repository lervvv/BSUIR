<?php

$inputFileResource = fopen("file1.dat", "rb");
$outputFileResource = fopen("file2.dat", "wb");

while (!feof($inputFileResource)) {
    $data = fread($inputFileResource, 2048);
    fwrite($outputFileResource, $data);
}

fclose($inputFileResource);
fclose($outputFileResource);
