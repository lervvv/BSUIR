<?php

echo filectime('C:/Windows/notepad.exe') . "\n"; // 1636203359 -- change time
echo filemtime('C:/Windows/notepad.exe') . "\n"; // 1636203359 -- modification time
echo fileatime('C:/Windows/notepad.exe') . "\n"; // 1646833333 -- last access time

var_dump(stat('C:/Windows/notepad.exe'));
/*
See https://www.php.net/manual/en/function.stat.php for details:
array(26) {
  [0] => int(4208659137)
  [1] => int(281474977580420)
  [2] => int(33279)
  [3] => int(3)
  [4] => int(0)
  [5] => int(0)
  [6] => int(0)
  [7] => int(208384)
  [8] => int(1646833333)
  [9] => int(1636203359)
  [10] => int(1636203359)
  [11] => int(-1)
  [12] => int(-1)
  'dev' => int(4208659137)
  'ino' => int(281474977580420)
  'mode' => int(33279)
  'nlink' => int(3)
  'uid' => int(0)
  'gid' => int(0)
  'rdev' => int(0)
  'size' => int(208384)
  'atime' => int(1646833333)
  'mtime' => int(1636203359)
  'ctime' => int(1636203359)
  'blksize' => int(-1)
  'blocks' => int(-1)
}
*/