<?php

print_r(pathinfo('c:/dir1/dir2/file.ext'));

/*
Array
(
    [dirname] => c:/dir1/dir2
    [basename] => file.ext
    [extension] => ext
    [filename] => file
)
*/