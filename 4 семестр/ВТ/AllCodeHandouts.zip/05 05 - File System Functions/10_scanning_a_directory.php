<?php

print_r(scandir('.'));

/*
Array
(
    [0] => .
    [1] => ..
    [2] => 01_predefined_constants.php
    ...
)
*/

$directoryDescriptor = opendir('.');
while (false !== ($objectName = readdir($directoryDescriptor))) {
    echo $objectName . ' = ' . filesize($objectName) . "\n";
}
closedir($directoryDescriptor);

/*
. = 4096
.. = 4096
01_predefined_constants.php = 139
...
*/