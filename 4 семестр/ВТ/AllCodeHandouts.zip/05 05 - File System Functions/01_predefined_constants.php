<?php

echo  DIRECTORY_SEPARATOR . "\n";
// On Windows: \
// On *nix: /

echo PATH_SEPARATOR . "\n";
// On Windows: ;
// On *nix: :