<?php

// To read the whole file at once:
$fileData = file_get_contents('C:/Windows/System32/drivers/etc/hosts');

// To read a part of a file:
$partialFileData = file_get_contents('C:/Windows/System32/drivers/etc/hosts', false, null, 100, 50);

// To overwrite a file:
file_put_contents('test.txt', $fileData);

// To append a file:
file_put_contents('test.txt', "\nNew line...", FILE_APPEND);

