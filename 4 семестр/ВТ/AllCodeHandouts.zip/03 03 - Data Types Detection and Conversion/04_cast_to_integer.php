<?php

var_dump((int)false);         // int(0)
var_dump((int)true);          // int(1)
var_dump((int)10.7);          // int(10)
var_dump((int)null);          // int(0)
var_dump((int)"Test");        // int(0)
var_dump((int)"5 Test");      // int(5)
var_dump((int)"2.5 Test");    // int(2)
var_dump((int)sqrt(-1)); // int(0)
var_dump((int)array(12));     // int(1)
var_dump((int)99e9999);       // int(0)


echo (int)((0.1 + 0.7) * 10); // echoes 7!

/* Floating point numbers have limited precision.
Although it depends on the system, PHP typically uses the IEEE 754 double precision format,
which will give a maximum relative error due to rounding in the order of 1.11e-16.
Non-elementary arithmetic operations may give larger errors, and, of course, error propagation
must be considered when several operations are compounded.

Additionally, rational numbers that are exactly representable as floating point numbers in base 10,
like 0.1 or 0.7, do not have an exact representation as floating point numbers in base 2,
which is used internally, no matter the size of the mantissa.
Hence, they cannot be converted into their internal binary counterparts without a small loss of precision.
This can lead to confusing results: for example, floor((0.1+0.7)*10) will usually return 7 instead
of the expected 8, since the internal representation will be something like 7.9999999999999991118....

So never trust floating number results to the last digit, and do not compare floating
point numbers directly for equality. If higher precision is necessary, the arbitrary
precision math functions and gmp functions are available.
*/