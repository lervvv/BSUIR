<?php

// Case 1:
$a = "10 cats";
$b = "5$a dogs";
$c = $a / $b;
var_dump($c); // double(0.019607843137255) (1/51) + WARNNIG

// Case 2:
$a = "10 cats";
$b = '5$a dogs';
$c = $a / $b;
var_dump($c); // int(2) + WARNING

// Case 3:
$a = true;
$b = "5$a dogs";
$c = $a / $b;
var_dump($c); // double(0.019607843137255) (1/51) + WARNING