<?php

var_dump((array)false);         // array(1) {[0] => bool(false)}
var_dump((array)true);          // array(1) {[0] => bool(true)}
var_dump((array)10.7);          // array(1) {[0] => double(10.7)}
var_dump((array)null);          // array(0) {}
var_dump((array)"Test");        // array(1) {[0] =>  string(4) "Test"}
var_dump((array)"5 Test");      // array(1) {[0] =>  string(6) "5 Test"}
var_dump((array)"2.5 Test");    // array(1) {[0] =>  string(8) "2.5 Test"}
var_dump((array)sqrt(-1)); // array(1) {[0] =>  double(NAN)}
var_dump((array)array(12));     // array(1) {[0] =>  int(12)}
var_dump((array)99e9999);       // array(1) {[0] =>  double(INF)}

$fileResource = fopen($_SERVER['PHP_SELF'], 'rb');
var_dump((array)$fileResource); // array(1) {[0] =>  resource(5) of type (stream)}

class SomeClass{};
var_dump((array)(new SomeClass)); // array(0) {}