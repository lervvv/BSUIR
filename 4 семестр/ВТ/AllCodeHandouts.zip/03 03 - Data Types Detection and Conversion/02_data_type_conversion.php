<?php

$someVariableOne = '1';  // $someVariableOne is a string
$someVariableTwo = $someVariableOne * 2; // $someVariableOne is still a string

$someStringOne = '10 oranges';
$someStringTwo = '2.5 lemons';
$someVariable = 5 * $someStringOne; // $someStringOne is still a string
$someVariable = 10 + $someStringTwo; // $someStringTwo is still a string

// Pay attention! If we assign the result to the same variable,
// it will change its type:
$someVariable = 1; // int
$someVariable = $someVariable * 2.5; // float

exit();

$someVariable = '50';
$someVariable = settype($someVariable, "innteger");

$someVariable = '50';
$someVariable = (int)$someVariable;

$someVariable = '50'; // string
$someVariable = (int)$someVariable; // int


// settype(mixed &$var, string $type): bool
$someVariable = '50';
$someVariable = settype($someVariable, "integer");

/*
 Possibles values of type are:
 "boolean" or "bool"
 "integer" or "int"
 "float" or "double"
 "string"
 "array"
 "object"
 "null"
*/