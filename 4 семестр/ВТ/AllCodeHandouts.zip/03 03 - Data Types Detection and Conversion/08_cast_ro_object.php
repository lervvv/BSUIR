<?php

var_dump((object)false);         // class stdClass#1 (1) {public $scalar =>  bool(false)}
var_dump((object)true);          // class stdClass#1 (1) {public $scalar =>  bool(true)}
var_dump((object)10.7);          // class stdClass#1 (1) {public $scalar =>  double(10.7)}
var_dump((object)null);          // class stdClass#1 (0) {}
var_dump((object)"Test");        // class stdClass#1 (1) {public $scalar =>  string(4) "Test"}
var_dump((object)"5 Test");      // class stdClass#1 (1) {public $scalar =>  string(6) "5 Test"}
var_dump((object)"2.5 Test");    // class stdClass#1 (1) {public $scalar =>  string(8) "2.5 Test"}
var_dump((object)sqrt(-1)); // class stdClass#1 (1) {public $scalar =>  double(NAN)}
var_dump((object)array(12));     // class stdClass#1 (1) {public $0 =>  int(12)}
var_dump((object)array('a' => 'A',
                       'b' => 'B'));  // class stdClass#1 (2) {public $a =>  string(1) "A"
                                      //                       public $b =>  string(1) "B"}
var_dump((object)99e9999);       // class stdClass#1 (1) {public $scalar =>  double(INF)}

$fileResource = fopen($_SERVER['PHP_SELF'], 'rb');
var_dump((object)$fileResource); // class stdClass#1 (1) {public $scalar =>  resource(5) of type (stream)}

class SomeClass{};
var_dump((object)(new SomeClass)); // class SomeClass#1 (0) {}