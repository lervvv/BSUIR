<?php

var_dump((string)false);         // string(0) ""
var_dump((string)true);          // string(1) "1"
var_dump((string)10.7);          // string(4) "10.7"
var_dump((string)null);          // string(0) ""
var_dump((string)"Test");        // string(4) "Test"
var_dump((string)"5 Test");      // string(6) "5 Test"
var_dump((string)"2.5 Test");    // string(8) "2.5 Test"
var_dump((string)sqrt(-1)); // string(3) "NAN"
var_dump((string)array(12));     // string(5) "Array" + WARNING
var_dump((string)99e9999);       // string(3) "INF"

$fileResource = fopen($_SERVER['PHP_SELF'], 'rb');
var_dump((string)$fileResource); // "Resource id #5" + WARNING

class SomeClass{};
var_dump((string)(new SomeClass)); // ERROR

