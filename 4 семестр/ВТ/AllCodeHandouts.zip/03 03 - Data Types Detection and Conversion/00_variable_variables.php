<?php

$initialVariable = 'Test';
$trickyVariable = 'initialVariable';
$evenMoreTrickyVariable = 'trickyVariable';

echo $initialVariable; // 'Test'
echo $$trickyVariable; // 'Test'
echo $$$evenMoreTrickyVariable; // 'Test'