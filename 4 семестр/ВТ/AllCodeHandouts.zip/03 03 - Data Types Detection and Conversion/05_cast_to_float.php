<?php

var_dump((float)false);         // double(0.0)
var_dump((float)true);          // double(1.0)
var_dump((float)10.7);          // double(10.7)
var_dump((float)null);          // double(0.0)
var_dump((float)"Test");        // double(0.0)
var_dump((float)"5 Test");      // double(5.0)
var_dump((float)"2.5 Test");    // double(2.5)
var_dump((float)sqrt(-1)); // double(NaN)
var_dump((float)array(12));     // double(1.0)
var_dump((float)99e9999);       // double(INF)