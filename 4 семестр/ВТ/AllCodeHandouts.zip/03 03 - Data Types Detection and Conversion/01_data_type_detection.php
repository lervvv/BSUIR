<?php

$someVariable = 'Test';
if (gettype($someVariable) == 'strinng') {
    // This condition is ALWAYS false!
    // Good luck to see why.
}

if (is_strinng($someVariable)) {
    // PHP immediately detects the problem.
}

//  gettype(mixed $value): string
$someVariable = 'Test';
echo gettype($someVariable);

/*
 Possible values for the returned string are:
 "boolean"
 "integer"
 "double" (for historical reasons "double" is returned in case of a float, and not simply "float")
 "string"
 "array"
 "object"
 "resource"
 "resource (closed)" as of PHP 7.2.0
 "NULL"
 "unknown type"
*/