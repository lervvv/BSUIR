<?php

$a = 1;
$b = 10;
$c = 0;
$d = -5;

if (is_finite($a + $b)) {
    echo ($a + $b) . "\n";
}

if (is_infinite(log($c))) {
    echo "Sorry, it is impossible to calculate log(" . $c . ")\n";
} else {
    echo log($c) . "\n";
}

if (is_nan(sqrt($d))) {
    echo "Sorry, it is impossible to calculate sqrt(" . $d . ") in real numbers.\n";
} else {
    echo sqrt($d) . "\n";
}