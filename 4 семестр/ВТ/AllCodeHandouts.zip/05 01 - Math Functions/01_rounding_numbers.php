<?php

echo round(3.4) . "\n"; // 3
echo round(3.5) . "\n"; // 4
echo round(3.6) . "\n"; // 4
echo round(3.6, 0) . "\n";   // 4
echo round(5.045, 2) . "\n"; // 5.05
echo round(5.055, 2) . "\n"; // 5.06
echo round(345, -2) . "\n";  // 300
echo round(345, -3) . "\n";  // 0
echo round(678, -2) . "\n";  // 700
echo round(678, -3) . "\n";  // 1000

echo ceil(4.3) . "\n";    // 5
echo ceil(9.999) . "\n";  // 10
echo ceil(-3.14) . "\n";  // -3

echo floor(4.3). "\n";   // 4
echo floor(9.999). "\n"; // 9
echo floor(-3.14). "\n"; // -4