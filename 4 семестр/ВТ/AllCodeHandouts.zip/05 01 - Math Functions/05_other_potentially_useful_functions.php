<?php

echo abs(-4.2) . "\n"; // 4.2
echo abs(5) . "\n";    // 5
echo abs(-5) . "\n";   // 5

echo pi() . "\n";; // 3.1415926535898
echo M_PI . "\n";; // 3.1415926535898

echo pow(2, 8) . "\n";    // 256
echo pow(-1, 20) . "\n";  // 1
echo pow(0, 0) . "\n";    // 1
echo pow(10, -1) . "\n";  // 0.1
echo pow(-1, 5.5) . "\n"; // NAN