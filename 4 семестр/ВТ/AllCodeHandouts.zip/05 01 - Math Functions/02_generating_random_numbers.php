<?php

// Get random integer
echo mt_rand(1, 999) . "\n";  // e.g., 743

// Get random float
function getRandomFloat(float $min, float $max) : float {
    if ($min >= $max) {
        throw new Exception("The minimum border should be less than a maximum border.");
    }
    return ($min + lcg_value() * (abs($max - $min)));
}

echo getRandomFloat(0.5, 0.7) . "\n"; // e.g., 0.51656109828938