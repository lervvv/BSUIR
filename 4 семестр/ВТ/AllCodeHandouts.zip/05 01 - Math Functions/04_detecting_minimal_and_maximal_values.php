<?php

$data = array(5, 3, 9, 2);

echo max($data) . "\n"; // 9
echo max(9, 12, 6, 8) . "\n";  // 12

echo min($data) . "\n"; // 2
echo min(9, 12, 6, 8) . "\n";  // 6

$data = array('Test', 'ABC', 'ZZZ', 'Just a string');

echo max($data) . "\n"; // ZZZ
echo min($data) . "\n"; // ABC