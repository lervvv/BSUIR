<?php

echo dechex(255) . "\n";       // ff
echo hexdec('ff') . "\n";  // 255

echo decbin(3) . "\n";         // 11
echo bindec('11') . "\n"; // 3

echo decoct(8) . "\n";         // 10
echo octdec('10') . "\n";  // 8

echo base_convert('AB', 16, 2) . "\n";  // 10101011