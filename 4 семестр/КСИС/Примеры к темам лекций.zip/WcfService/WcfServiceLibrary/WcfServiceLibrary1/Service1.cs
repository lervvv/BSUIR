﻿using System;
using System.ServiceModel;

namespace WcfServiceLibrary1
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession,
        ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class WeatherService : IWeatherService
    {
        public WeatherService()
        {
            Console.WriteLine("WeatherService instance created");
        }

        public double GetTemperature(string location)
        {
            return +15;
        }

        public WeatherInfo GetWeatherInfo(string location)
        {
            WeatherInfo result = new WeatherInfo()
            {
                Temperature = 15,
                Humidity = 65,
                Pressure = 710,
            };
            return result;
        }

        static void Main()
        {
            var host = new ServiceHost(typeof(WeatherService));
            host.Open();
            Console.WriteLine("Press any key to stop the service");
            Console.ReadKey();
        }
    }
}
