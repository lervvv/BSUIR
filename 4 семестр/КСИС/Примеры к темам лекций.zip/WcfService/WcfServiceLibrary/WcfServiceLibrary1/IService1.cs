﻿using System.Runtime.Serialization;
using System.ServiceModel;

namespace WcfServiceLibrary1
{
    [ServiceContract(Name = "WeatherService", 
        Namespace = "http://example.com/weather/2021/05/24")]
    public interface IWeatherService
    {
        [OperationContract]
        double GetTemperature(string location);

        [OperationContract]
        WeatherInfo GetWeatherInfo(string location);
    }

    [DataContract]
    public class WeatherInfo
    {
        public WeatherInfo()
        {
        }

        [DataMember]
        public double Temperature { get; set; }

        [DataMember]
        public double Humidity { get; set; }

        [DataMember]
        public double Pressure { get; set; }

        public double GetTemperatureAsFahrenheit()
        {
            return Temperature * 9 / 5 + 32;
        }
    }
}
