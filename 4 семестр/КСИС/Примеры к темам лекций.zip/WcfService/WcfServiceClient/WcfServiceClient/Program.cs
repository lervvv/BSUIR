﻿using System;
using WcfServiceClient.WeatherServiceReference;

namespace WcfServiceClient
{
    class Program
    {
        static void Main(string[] args)
        {
            var client = new WeatherServiceClient();
            var t = client.GetTemperature("Minsk");
            Console.WriteLine("Temperature: {0}", t);
            var w = client.GetWeatherInfo("Minsk");
            Console.WriteLine("Temperature: {0}, Humidity: {1}, Pressure: {2}",
                w.Temperature, w.Humidity, w.Pressure);
            client.Close();
            Console.ReadKey();
        }
    }
}
