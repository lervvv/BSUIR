﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace TcpServer
{
    class Program
    {
        static string ipAddress = "127.0.0.1"; // адрес сервера для локальных клиентов
        static int port = 5555; // порт для приема входящих запросов
        static void Main(string[] args)
        {
            // Создаём точку доступа к службе (адрес и порт)
            IPEndPoint ipPoint = new IPEndPoint(IPAddress.Parse(ipAddress), port);
            try
            {
                // Создаем гнездо
                Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                // Связываем гнездо с точкой доступа
                socket.Bind(ipPoint);
                // Переводим гнездо в режим прослушивания (создаём очередь запросов на подключение клиентов)
                socket.Listen(10);
                Console.WriteLine("Сервер ожидает подключений...");
                while (true)
                {
                    // Ожидаем запроса на подключение клиента и принимаем его
                    Socket clientSocket = socket.Accept();
                    // Взаимодействуем с клиентом
                    CommunicateWithClient(clientSocket);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void CommunicateWithClient(Socket clientSocket)
        {
            StringBuilder inputMessage = new StringBuilder(); // накапливаемое сообщение
            int bytesRead = 0; // количество байтов, полученных за одну операцию чтения
            byte[] inputData = new byte[256]; // буфер для получаемых данных
            // Получаем данные в цикле пока гнездо не закроется на чтение
            do
            {
                // Читаем пришедшую порцию данных
                bytesRead = clientSocket.Receive(inputData);
                // Перекодируем данные из формата UTF8 в строку в формате Unicode
                string text = Encoding.UTF8.GetString(inputData, 0, bytesRead);
                // Добавляем принятый текст (строку в формате Unicode)
                inputMessage.Append(text);
            }
            while (bytesRead > 0);

            // Выводим на экран текст принятого сообщения для отладки
            Console.WriteLine(DateTime.Now.ToLongTimeString() + " - " + inputMessage.ToString());

            string outputMessage = "Ваше сообщение доставлено"; // ответ клиенту
            // Перекодируем текст в формате Unicode в данные в формате UTF8
            byte[] outputData = Encoding.UTF8.GetBytes(outputMessage);
            // Отправляем данные клиенту (цикл отправки порциями реализует .NET)
            clientSocket.Send(outputData);

            // Закрываем дуплексное соединение с клиентом
            clientSocket.Shutdown(SocketShutdown.Both);
            // Уничтожаем гнездо и освобождаем его ресурсы (буферы, таймеры, счётчики)
            clientSocket.Close();
        }
    }
}
