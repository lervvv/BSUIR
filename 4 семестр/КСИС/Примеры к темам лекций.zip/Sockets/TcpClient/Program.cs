﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace TcpClient
{
    class Program
    {
        static string ipAddress = "127.0.0.1"; // адрес сервера
        static int port = 5555; // порт сервера
        static void Main(string[] args)
        {
            // Создаём точку доступа к службе (адрес и порт)
            IPEndPoint ipPoint = new IPEndPoint(IPAddress.Parse(ipAddress), port);
            try
            {
                // Создаем гнездо
                Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                // Подключаемся к серверу. IP-адрес и порт клиенту назначаются автоматически
                socket.Connect(ipPoint);

                // Взаимодействуем с сервером
                CommunicateWithServer(socket);

                // Закрываем дуплексное соединение с сервером
                socket.Shutdown(SocketShutdown.Both);
                // Уничтожаем гнездо и освобождаем его ресурсы (буферы, таймеры, счётчики)
                socket.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.Read();
        }

        static void CommunicateWithServer(Socket socket)
        {
            Console.Write("Введите сообщение: ");
            string outputMessage = Console.ReadLine(); // сообщение серверу
            // Перекодируем текст в формате Unicode в данные в формате UTF8
            byte[] outputData = Encoding.UTF8.GetBytes(outputMessage);
            socket.Send(outputData);
            // Закрываем соединение на отправку данных
            socket.Shutdown(SocketShutdown.Send);

            StringBuilder inputMessage = new StringBuilder(); // накапливаемое сообщение
            int bytesRead = 0; // количество байтов, полученных за одну операцию чтения
            byte[] inputData = new byte[256]; // буфер для получаемых данных
            // Получаем данные в цикле пока гнездо не закроется на чтение
            do
            {
                // Читаем пришедшую порцию данных
                bytesRead = socket.Receive(inputData);
                // Перекодируем данные из формата UTF8 в строку в формате Unicode
                string text = Encoding.UTF8.GetString(inputData, 0, bytesRead);
                // Добавляем принятый текст (строку в формате Unicode)
                inputMessage.Append(text);
            }
            while (bytesRead > 0);

            // Выводим на экран текст принятого сообщения для отладки
            Console.WriteLine("Ответ сервера: " + inputMessage.ToString());
        }
    }
}
