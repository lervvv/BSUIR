/*
    "База данных"
*/

let db = {
    posts: {},
    lastId: 0,
}

const fs = require('fs')
const path = require('path')

const dbFilePath = path.join(__dirname, 'db.json')

if (fs.existsSync(dbFilePath)) {
    console.log('Загрузка базы с диска...')
    db = JSON.parse(fs.readFileSync(dbFilePath))
    console.log('Загружено записей: ' + Object.keys(db.posts).length)
}
else {
    console.log('Сохранённой базы не найдено!')
}

function nextId() {
    return ++db.lastId
}

function saveDbToDisk() {
    console.log('Сохранение базы на диск...')
    fs.writeFileSync(dbFilePath, JSON.stringify(db, undefined, 2))
    console.log('Сохранено записей: ' + Object.keys(db.posts).length)
}

/*
    Веб-служба
*/

const express = require('express')

const app = express()

// Обработка тела запроса в формате JSON
app.use(express.json())

// Настройка точек доступа к службе

// * Создать новую запись
app.post('/posts', (req, res) => {
    const newId = nextId()
    const newPost = {
        id: newId,
        title: req.body['title'],
        text: req.body['text'],
        createdAt: Date.now(),
    }
    db.posts[newId] = newPost
    saveDbToDisk()
    res.status(200).send(`Post created #${newId}`)
})

// * Получить список записей
app.get('/posts', (req, res) => {
    const withText = (req.query['withText'] == 1)
    const result = Object.keys(db.posts).map(key => {
        const post = db.posts[key]
        return {
            id: key,
            title: post.title,
            text: withText ? post.text : undefined
        }
    })
    res.status(200).send(result)
})

// * Получить представление записи #id
app.get('/posts/:id', (req, res) => {
    const id = req.params['id']
    const post = db.posts[id]
    if (post !== undefined) {
        const result = {
            id: post.id,
            title: post.title,
            text: post.text
        }
        res.status(200).send(result)
    }
    else {
        res.status(404).send(`Not found #${id}`)
    }
})

// * Обновить содержимое записи #id
app.put('/posts/:id', (req, res) => {
    const id = req.params['id']
    const post = db.posts[id]
    if (post !== undefined) {
        const updatedPost = {
            id: post.id,
            title: req.body.title,
            text: req.body.text,
            createdAt: post.createdAt,
            updatedAt: Date.now(),
        }
        db.posts[id] = updatedPost
        saveDbToDisk()
        res.status(200).send(`Post updated #${id}`)
    }
    else {
        res.status(404).send(`Not found #${id}`)
    }
})

// * Удалить запись #id
app.delete('/posts/:id', (req, res) => {
    const id = req.params['id']
    delete db.posts[id]
    saveDbToDisk()
    res.status(200).send('Deleted')
})

// Запуск сервера

const port = 3000

app.listen(port, () => {
    console.log(`*** Служба доступна по адресу http://localhost:${port}/`)
})
