# Пример RESTful службы на основе Express.js

## Установка и запуск
1. Установить NodeJS (LTS-версию) - https://nodejs.org/.
2. Установить необходимые зависимости - `npm install` в текущей директории.
3. Запустить службу - `npm start`.

Служба доступна по адресу http://localhost:3000.

## Точки доступа к службе
- `POST /posts` **+ тело** - создать новую запись.
- `GET /posts` - получить список записей (идентификатор, заголовок).
  - параметр `?withText=1` позволяет дополнительно получить текст записей.
- `GET /posts/{id}` - получить представление записи с идентификатором `{id}`.
- `PUT /posts/{id}` **+ тело** - обновить содержимое записи `{id}`.
- `DELETE /posts/{id}` - удалить запись `{id}`.

Формат **тела** запроса для методов `POST` и `PUT` - JSON (заголовок `Content-Type: application/json`):

```json
{
    "title": "Заголовок",
    "text": "Текст записи"
}
```

## Примеры запросов для браузера (GET)
- http://localhost:3000/posts/
- http://localhost:3000/posts/?withText=1
- http://localhost:3000/posts/2
- http://localhost:3000/posts/some-invalid-id
